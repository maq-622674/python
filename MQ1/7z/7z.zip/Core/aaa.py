def aaa():
    b=0
    return b

aaa()