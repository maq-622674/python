from Core.Local import local
from Armoury import fso
import sys

if local.ECHO_PRINT:
    sys.stderr = local.STDERR
if local.ECHO_ERR:
    sys.stdout=local.STDOUT
print("===================")
print("=======MaQue=======")
import os
print("A",os.getpid())
local.init_mq()
print("=======Init Finish=======")
local.echo("start","MaQue:",local.VER,"webport:",local.PORT_WEB)

