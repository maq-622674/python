######################################################
# 网页访问函数
######################################################
from . import jws
from Core.Local import local
from Armoury import fso
import cgi
from Core.Local import plugmgmt
import os
import json
from http.cookies import SimpleCookie

def page_index(req:jws.classRequest):
    return req.render(fso.appHome("html/debug.html"),ver=local.VER,myid=local.MY_ID)

def page_upload(req:jws.classRequest):
    """
    上传接口测试页面
    """
    print("UPLOAD EVENT")
    if req.METHOD=="GET":
        return req.render(fso.appHome("html/upload.html"))
    elif req.METHOD=="POST":
        rejs={"result":"false"}
        tmpfold=fso.appfold("tmp/upload_files")
        fso.foldexist(tmpfold)
        fields = cgi.FieldStorage(fp=req.ENVIRON['wsgi.input'],environ=req.ENVIRON, keep_blank_values=1)
        # print(fields)
        fileitem = fields['itemname']
        if "path" in fields:
            # 需要转移到特殊的文件夹下
            for usr in plugmgmt.get_plug_accounts():
                tmpfold=fso.appfold("user/"+usr+"/"+fields["path"].value)
                if os.path.exists(tmpfold):
                    break
            else:
                # 没有找到文件夹，返回错误
                return json.dumps(rejs)

        if type(fileitem)==type(list):
            rejs["size"]=0
            rejs["filename"]=""
            for fil in fileitem:
                dat=fil.file.read()
                open(tmpfold+ '/'+fil.filename, 'wb').write(dat)
                rejs["size"]+=len(dat)
                rejs["filename"]+="/"+fil.filename
            rejs["size"]=str(rejs["size"])
            rejs["result"]="ok"
        else:
            newname=""
            if "newname" in fields:
                newname=fields["newname"].value
            print("new name ==",newname)
            if newname==""  :newname=fileitem.filename
            dat=fileitem.file.read()
            open(tmpfold+ '/'+newname, 'wb').write(dat)
            rejs["filename"]=newname
            rejs["size"]=str(len(dat))
            rejs["result"]="ok"
        return json.dumps(rejs)

def page_cookie(req:jws.classRequest):
    """
    """
    print("访问cookie页面")
    getcookie=req.cookie_get("act","error")
    print("act :",getcookie)
    allcookie=req.cookie_get("","error")
    print("all :",allcookie)
    req.cookie_set("act","hgmmym")
    # req.cookie_clear()
    return "test cookie"


