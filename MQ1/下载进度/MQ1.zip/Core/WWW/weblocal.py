####################################################################
#   网页管理模块
####################################################################
from threading import Thread
from Core.Local import local
from Core.Local import ccc
from . import jws
from . import webpage

from Armoury import fso
#
JWSCLS=jws.classWSGI

def cmd_test(jsl,rejsl):
    """
    """
    print(fso.now())
    rejsl["msg"]="good day!"
    rejsl["result"]="ok"

def init_web():
    """
    """
    global JWSCLS
    JWSCLS=jws.classWSGI("",local.PORT_WEB)
    JWSCLS.route("/",webpage.page_index)
    JWSCLS.route("/debug",webpage.page_index)
    JWSCLS.route("/upload",webpage.page_upload)
    JWSCLS.route("/cookie",webpage.page_cookie)
    JWSCLS.route_file("/File",fso.appHome("static"))
    #JWSCLS.route_file("/File",fso.appHome("static"))
    JWSCLS.load_cmd("test",cmd_test)
    JWSCLS.load_cmd("alias",ccc.cmd_alias)
    JWSCLS.load_cmd("cmd",ccc.cmd_cmd,"cmd")
    JWSCLS.load_cmd("cpu",ccc.cmd_cpu)
    JWSCLS.load_cmd("createplug",ccc.cmd_createplug,"account","name")
    JWSCLS.load_cmd("info",ccc.cmd_info)
    JWSCLS.load_cmd("route",ccc.cmd_route)
    JWSCLS.load_cmd("rs",ccc.cmd_rs)
    JWSCLS.load_cmd("thrlist",ccc.cmd_thrlist)
    JWSCLS.load_cmd("time",ccc.cmd_time)
    JWSCLS.load_cmd("update",ccc.cmd_update)
    ##################################
    JWSCLS.load_cmd("new",ccc.cmd_new)
    ##################################
    JWSCLS.load_cmd("ver",ccc.cmd_ver)
    JWSCLS.load_plug("plug","test",ccc.plug_test)
    thr=Thread(target=JWSCLS.start,name="WEB_START")
    thr.start()
    # JWSCLS.start()
