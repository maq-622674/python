//常规api入口
function api_get(param) {
    var data = "";
    for (var itm in param) {
        if (param.hasOwnProperty(itm)) {
            data += itm + "=" + param[itm] + "&";
        }
    }
    data = data.slice(0, data.length - 1);
    var url = LOCAL_URL + data;
    var jsobj = {};
    try {
        var resp = $.ajax({ 
            url, 
            async: false,
            cache: false, 
            timeout: 5000
        }).responseText;
        var jsobj = JSON.parse(resp);
        if (jsobj.hasOwnProperty("result") === false) {
            jsobj["result"] = "fasle";
            jsobj["errmsg"] = "response_error";
        }
    }
    catch (e) {
        jsobj["result"] = "fasle";
        jsobj["errmsg"] = "response_error";
    }
    return jsobj;
}

function ajaxGet(url,callbackfunc) {
    return new Promise(function(resolve, reject) {
        $.ajax({
            url: url,
            type: 'GET',
            success: function(res) {
                // resolve(res);
                callbackfunc(res);
            },
            error: function(err) {
                reject(url + '这个接口请求失败')
                //callbackfunc(err);
                // add_msg(JSON.stringify(err));
            }
        })
    })
};
async function api_get_async(param,callbackfunc,errcallback) {
    var data = "";
    for (var itm in param) {
        if (param.hasOwnProperty(itm)) {
            data += itm + "=" + param[itm] + "&";
        }
    }
    data = data.slice(0, data.length - 1);
    try {
        let result = await ajaxGet(LOCAL_URL+data,callbackfunc); // 执行到这里报错，直接跳至下面 catch() 语句
    } catch (err) {
        errcallback();
    }
}


//默认使用的是plug端口，后端默认占用了account键值
function plug_get(param) {
    var data = "";
    for (var itm in param) {
        if (param.hasOwnProperty(itm)) {
            data += itm + "=" + param[itm] + "&";
        }
    }
    data = data.slice(0, data.length - 1);
    var url = PLUG_URL + data;
    var jsobj = JSON.parse($.ajax({ url, async: false, cache: false, timeout: 5000 }).responseText);
    if (jsobj.hasOwnProperty("result") === false) {
        jsobj["result"] = "fasle";
        jsobj["errmsg"] = "response_error";
    }
    return jsobj;
}
