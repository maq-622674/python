"""
Minipi API功能调用区
    本文件主要针对其他minipi客户端进行API调用，进行JS的数据通讯

2019年9月10日 19点26分
"""

from Armoury import fso
from Armoury import sock

def getApiPort(devsn:str)->str:
    """
    在pigeon server上找到指定序列号的minipi设备的API端口
    {"result": "ok", "action": "search", "list": [
        {"servername": "API", "serverport": "7077", "name": "__API_P194307", 
            "port": "50000", "status": "online"}, 
        {"servername": "PGN", "serverport": "7050", "name": "P194307_yoyoyo2", 
            "port": "30005", "status": "online"}, 
        {"servername": "SSH", "serverport": "7022", "name": "__SSH_P194307", 
            "port": "22000", "status": "online"}
        ]
    }
    """
    pass
