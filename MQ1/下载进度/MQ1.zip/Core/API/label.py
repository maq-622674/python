"""
标签系统
2019年3月2日15:30:10

标签原则一：标签为一种常规类型硬件或软件的值，例如 ：
    label.jimuti.localdevice.wifilist （只读） 返回当前搜索到的无线的名称

2019年9月2日 01点56分
标签系统设置：
    [Label]
    Name : 标签名称
    Type : input / output / echo
    Mode : io / ser1 / get
    Value : "http://eventurl"   
        （input:当标签指定的mode通讯产生指定的值，会产生触发）
        （output：当标签被触发，将指定的值送到指定的mode通讯）
        （echo：与input相同）
    <DevSN> : 可选项 ， 指定的minipi设备SN号码
    [ EchoValue ] : 当type为echo时需要填写的项目，内容为当 output的值

当设置的类型
    类型为 input:
    函数返回 LabelIndex 与 ""
    （仅有输出，不需要输入的设备，例如按钮，门磁）

    类型为 output:
    函数返回 LabelIndex 与 LabelAPI
    （仅有输入，不需要输出的设备，例如灯，屏幕）

    类型为 echo：
    函数返回 LabelIndex 与 LabelEchoAPI
    （带有输入，并且带有输出，并且需要返回回音链的设备，例如屏幕指定开关）

"""
import json
from Core.Dev import dev
from Core.Dev import serp
from Armoury import fso
from Armoury import errbox
from Armoury import sock


class labelClass:
    """
    标签类函数
    """
    def __init__(self,inipath:str,jssObject:sock.JSServer):
        """
        inipath : 配置文件的绝对路径
        jssObject : jsserver实例对象，用于添加echo的键值
                    目前jss为plug_manage
        """
        self.__inifile=inipath
        self.__jsSvr=jssObject

        self.ALLOW_TYPE_LIST=["input","output","echo"]
        self.ALLOW_MODE_LIST=["io","ser1","get"]
        self.__labelInfo={
            "1234":{
                "info":self.labelInfoClass,
                "ptr":[0],        # 回调函数保存列表，当本标签被触发，会回调这个列表内的所有函数
            }
        }
        self.__labelInfo.clear()
        # 加载所有之前的标签
        rall=fso.rallini(inipath)
        for inx in rall:
            self.__loadLabels(  rall[inx]["name"],
                                inx,
                                rall[inx]["type"],
                                rall[inx]["mode"],
                                rall[inx]["value"],
                                rall[inx]["echovalue"],
                                rall[inx]["devsn"])


    def addLabel(self, name:str,
        labelType : str ,
        labelMode : str ,
        labelValue : str,
        labelEchoValue:str ="" ,
        devSN:str="" )->(str,str):
        """
        创建标签
        当使用串口，值可以填写0x0?来代表16进制字节值

        """
        # 记录输入值
        rndno=str(fso.rnd_number(1000,9999))
        if self.__loadLabels(name,rndno,labelType,
                            labelMode,labelValue,labelEchoValue,devSN):
            fso.wini(self.__inifile,rndno,"name",name)
            fso.wini(self.__inifile,rndno,"type",labelType)
            fso.wini(self.__inifile,rndno,"mode",labelMode)
            fso.wini(self.__inifile,rndno,"value",labelValue)
            fso.wini(self.__inifile,rndno,"echovalue",labelEchoValue)
            fso.wini(self.__inifile,rndno,"devsn",devSN)

            # 生成API
            return rndno
        else:
            return ""

    def delLabel(self,name:str):
        """
        删除标签，删除指定名称标签
        """
        obj=self.getLabel(name)
        if obj.NAME=="":
            return
        #删除ini和list
        del self.__labelInfo[obj.INDEX]
        self.__jsSvr.del_plug("echo",obj.INDEX)
        self.__jsSvr.del_plug("label",obj.INDEX)
        if obj.MODE=="io":
            dev.delEvent(obj.INDEX)
        elif obj.MODE=="ser1":
            serp.delEvent(obj.VALUE)
        fso.delini(self.__inifile,obj.INDEX)

    def getLabel(self,nameOrIndex:str):
        """
        通过标签名称或者完整的标签ID获取标签的信息结构
        """
        nameOrIndex=str(nameOrIndex)
        for inx in self.__labelInfo:
            if (nameOrIndex==inx or 
                nameOrIndex==self.__labelInfo[inx]["info"].NAME):
                return self.__labelInfo[inx]["info"]
        tmpobj=self.labelInfoClass()
        return tmpobj
        
    def listLabel(self)->list:
        """
        列出本系统内所有的label，返回[{}...]
        """
        ll=[]
        # ifo:self.labelInfoClass=self.__labelInfo[itm]["info"]
        for itm in self.__labelInfo:
            tmpif={}
            ifo=self.__labelInfo[itm]["info"]
            tmpif["name"]=ifo.NAME
            tmpif["index"]=ifo.INDEX
            tmpif["mode"]=ifo.MODE
            tmpif["type"]=ifo.TYPE
            tmpif["value"]=fso.rini(self.__inifile,ifo.INDEX,"value","[null]")
            ll.append(tmpif)
        return ll

    def showLabel(self):
        """
        打印当前所有label
        """
        show=fso.showBox()
        show.addMsg("Label System Info :")
        show.addHead("Index","Name","Type","Mode","Value","EchoValue","DevSN")
        for itm in self.__labelInfo:
            # ifo:self.labelInfoClass=self.__labelInfo[itm]["info"]
            ifo=self.__labelInfo[itm]["info"]
            valstr=ifo.VALUE
            if ifo.MODE=="ser1":
                valstr=""
                for vulitm in ifo.VALUE:
                    valstr+=str(vulitm)+","
                valstr=valstr.strip(",")
                print(bytes(ifo.VALUE))
                print("##############>",valstr,"<###########")
            show.addItem(itm,ifo.NAME,ifo.TYPE,ifo.MODE,valstr,ifo.ECHOVALUE,ifo.DEVSN)
        show.show()

    def execLabel(self,labelIndex:str):
        """
        执行指定编号的label
        """
        jsl={"label":labelIndex}
        self.__eventExecLabel(jsl,{})

    def addEvent(self,labelIndex:str,ptrfun):
        """
        将指定的label绑定到指定的回调函数
        回调格式 ： fun( label )
        """
        if labelIndex not in self.__labelInfo:
            errbox.log("labelindex NOE",True)
            return
        if ptrfun in self.__labelInfo[labelIndex]["ptr"]:
            errbox.log("ADD-EVENT-ERR:ptr is exist",True)
            return
        self.__labelInfo[labelIndex]["ptr"].append(ptrfun)

    def __loadLabels(self, name:str,
        labelIndex:str,
        labelType : str ,
        labelMode : str ,
        labelValue : str,
        labelEchoValue:str ="" ,
        devSN:str="")->bool:
        """
        载入标签，将标签载入信息表
        """
        if (name=="" or
            labelType not in self.ALLOW_TYPE_LIST or
            labelMode not in self.ALLOW_MODE_LIST or 
            labelValue=="" or
            (labelType=="echo" and labelEchoValue=="")):
            # 不允许无名标签
            # 检查输入是否合法
            # 检查输入echo有没有输入echovalue
            return False

        errbox.log("LoadLabel:"+labelType+" "+labelMode+" "+labelIndex,True)
        # 生成临时的随机码，作为序号
        rndno=labelIndex

        tmpif=self.labelInfoClass()
        tmpif.NAME=name
        tmpif.TYPE=labelType
        tmpif.MODE=labelMode
        tmpif.VALUE=labelValue
        tmpif.ECHOVALUE=labelEchoValue
        tmpif.DEVSN=devSN
        tmpif.INDEX=rndno
        # 特殊值处理
        if labelType=="input":
            res=self.__loadInput(tmpif)
            if not res:
                return res
        elif labelType=="output":
            res=self.__loadOutput(tmpif)
            if not res:
                return res
            self.__jsSvr.load_plug("label",rndno,self.__eventExecLabel)
        elif labelType=="echo":
            res=self.__loadEcho(tmpif)
            if not res:
                return res
            self.__jsSvr.load_plug("echo",rndno,self.__eventExecLabel)
        # 将这个结构送入信息列表,ptr为触发本label后需要返回的指针
        self.__labelInfo[rndno]={"info":tmpif,"ptr":[]}
        return True

    
    def __loadInput(self,tmpif)->bool:
        """
        """
        if tmpif.MODE=="io":
            # 使用IO，必须填入dict的字符串类型
            # 例如{"ionum":"3" , "value":"1"}
            # 值为引脚3变成电平1
            try:
                iojs=json.loads(tmpif.VALUE)
                if "ionum" in iojs and "value" in iojs:
                    res=self.__eventAdd(tmpif.INDEX,"io",tmpif.VALUE)
                    if not res:
                        errbox.log("inputArgu err:"+str(tmpif.VALUE),True)
                        return False
                    tmpif.VALUE=iojs
                else:
                    # 值没有关键词
                    errbox.log("inputArgu no ionum/value:"+str(tmpif.VALUE),True)
                    return False
            except Exception as e:
                # 值不能转换为dict
                print(repr(e))
                errbox.log("inputArgu no DICT:"+str(tmpif.VALUE),True)
                return False
        elif tmpif.MODE=="ser1":
            # 使用串口1，直接填写字符串，如果需要字节表示，可以使用0x010x02
            # 0x**会被替换成指定的字节数据
            hexchar="0x"
            vals=tmpif.VALUE.split(hexchar)
            valuelist=[]
            for itm in vals:
                if itm!="":
                    if len(itm)>1:
                        valuelist.append(int(itm[:2],16))
                        for itm in itm[2:].encode():
                            valuelist.append(itm)
                    else:
                        valuelist.append(itm.encode())
            tmpif.VALUE=bytes(valuelist)
            # initxt=""
            # for itm in cstr.encode():
            #     initxt+=","+str(itm)
            # labelValue=initxt.strip(",")
            self.__eventAdd(tmpif.INDEX,"ser1",tmpif.VALUE)
        else:
            errbox.log("unknow input mode"+tmpif.MODE,True)
            return False
        return True

    def __loadOutput(self,tmpif)->bool:
        """
        """
        if tmpif.MODE=="io":
            # 使用IO，必须填入dict的字符串类型
            # 例如{"ionum":"3" , "value":"1"}
            # 值为引脚3变成电平1
            try:
                iojs=json.loads(tmpif.VALUE)
                if "ionum" in iojs and "value" in iojs:
                    tmpif.VALUE=iojs
                    # 强制打开指定引脚
                    dev.iouse(tmpif.VALUE["ionum"])
                    dev.iomode(tmpif.VALUE["ionum"],False)
            except:
                # 值不能转换为dict
                errbox.log("IO argu not dict"+str(tmpif.VALUE),True)
                return False
            # 在jssvr的plug api里面生成label的action
            # plug=label label=labelIndex

        elif tmpif.MODE=="ser1":
            # 使用串口1，直接填写字符串，如果需要字节表示，可以使用0x010x02
            # 0x**会被替换成指定的字节数据
            hexchar="0x"
            vals=tmpif.VALUE.split(hexchar)
            valuelist=[]
            # 如果分割出来的第一个是空，则考虑第一位就是0x开头
            # 如果不是空，则第一位不是0x开头
            if vals[0]=="":
                for itm in vals:
                    if itm!="":
                        if len(itm)>1:
                            valuelist.append(int(itm[:2],16))
                            for itmchr in itm[2:].encode():
                                valuelist.append(itmchr)
                        else:
                            valuelist.append(itm.encode())
            else:
                # 优先处理第一位，后面的再循环处理
                for itmchr in vals[0].encode():
                    valuelist.append(itmchr)
                for itm in vals[1:]:
                    if itm!="":
                        if len(itm)>1:
                            valuelist.append(int(itm[:2],16))
                            for itmchr in itm[2:].encode():
                                valuelist.append(itmchr)
                        else:
                            valuelist.append(itm.encode())
            tmpif.VALUE=bytes(valuelist)
            serp.start(1)
        else:
            errbox.log("unknow input mode"+tmpif.MODE,True)
            return False
        return True

    def __loadEcho(self,tmpif)->bool:
        """
        value : input的截获值
        echovalue : 当本label的功能在回音链中被别的功能执行的时候，反向发送的值,就是output
        """
        errbox.log("Loading-Echo-Input",True)
        res=self.__loadInput(tmpif)
        if not res:
            return res
        errbox.log("Loading-Echo-Output",True)
        if tmpif.MODE=="io":
            # 使用IO，必须填入dict的字符串类型
            # 例如{"ionum":"3" , "value":"1"}
            # 值为引脚3变成电平1
            if not dev.IO_SUPPORT:
                return False
            try:
                iojs=json.loads(tmpif.ECHOVALUE)
                if "ionum" in iojs and "value" in iojs:
                    tmpif.ECHOVALUE=iojs
                    # 强制打开指定引脚
                    dev.iouse(tmpif.ECHOVALUE["ionum"])
                    dev.iomode(tmpif.ECHOVALUE["ionum"],False)
            except:
                # 值不能转换为dict
                errbox.log("IO argu not dict"+str(tmpif.ECHOVALUE),True)
                return False
            # 在jssvr的plug api里面生成label的action
            # plug=label label=labelIndex
 
        elif tmpif.MODE=="ser1":
            # 使用串口1，直接填写字符串，如果需要字节表示，可以使用0x010x02
            # 0x**会被替换成指定的字节数据
            hexchar="0x"
            vals=tmpif.ECHOVALUE.split(hexchar)
            valuelist=[]
            # 如果分割出来的第一个是空，则考虑第一位就是0x开头
            # 如果不是空，则第一位不是0x开头
            if vals[0]=="":
                for itm in vals:
                    if itm!="":
                        if len(itm)>1:
                            valuelist.append(int(itm[:2],16))
                            for itmchr in itm[2:].encode():
                                valuelist.append(itmchr)
                        else:
                            valuelist.append(itm.encode())
            else:
                # 优先处理第一位，后面的再循环处理
                for itmchr in vals[0].encode():
                    valuelist.append(itmchr)
                for itm in vals[1:]:
                    if itm!="":
                        if len(itm)>1:
                            valuelist.append(int(itm[:2],16))
                            for itmchr in itm[2:].encode():
                                valuelist.append(itmchr)
                        else:
                            valuelist.append(itm.encode())
            tmpif.ECHOVALUE=bytes(valuelist)
            serp.start(1)
        else:
            errbox.log("unknow input mode"+tmpif.MODE,True)
            return False
        errbox.log("Load-Echo-Success",True)
        return True



    def __eventAdd(self,labelIndex:str,labelMode:str,labelValue:str,)->bool:
        """
        将IO GET SER1类型的触发事件绑定到标签系统，
        并自动生成触发
        仅在labelType是input和echo时作判断，请注意
        """
        if labelMode=="io":
            # 判断输入的value是否合法
            jsval=json.loads(labelValue)
            if "ionum" not in jsval or "value" not in jsval:
                errbox.log("Label-Event: "+labelIndex+" IO-ERROR",True)
                return False 
            ionum=jsval["ionum"]
            val=jsval["value"]
            dev.addevent(labelIndex,ionum,val,self.__eventIOTrigger)
        elif labelMode=="get":
            pass
        elif labelMode=="ser1":
            print("Add-Label-Event:[Ser1]")
            serp.start(1)
            serp.addevent(labelValue,self.__eventSer1Trigger)
        else:
            errbox.log("Unknow Label Mode: "+labelMode,True)
            return False
        return True

    def __eventIOTrigger(self,labelIndex):
        """
        当添加的标签产生了事件，
        这里是IO事件指向的入口
        """
        errbox.log("LABEL-EVENT-UP:"+labelIndex,True)

    def __eventSer1Trigger(self,ser1Bytes):
        """
        当添加的标签产生了事件，
        这里是串口事件指向的入口

        当接收到的串口数据的最后一截数据包含了指定的切割符，
        则会将数据返回到本函数，产生触发。
        如果多个相同的功能的切割符相同，则全部相同切割符的函数都会触发。
        """
        print("Bytes:",ser1Bytes)
        for itm in self.__labelInfo:
            # ifo=self.labelInfoClass
            ifo=self.__labelInfo[itm]["info"]
            if ifo.MODE=="ser1":
                if ifo.VALUE==ser1Bytes[0-len(ifo.VALUE):]:
                    print("LABEL-SER1-DATAIN:"+ifo.INDEX)
                    # 模式是串口1，并且切割符与串口收到的数据的最后一截一致
                    for ptrfun in self.__labelInfo[itm]["ptr"]:
                        ptrfun(ifo.INDEX)


    def __eventExecLabel(self,jsl,rejsl):
        """
        当output的label被外部api调用时，所有的label都在此被执行
        """
        print("#############Into_Label_ExecFunction###########")
        typ=jsl["plug"]
        inx=jsl["action"]
        if inx not in self.__labelInfo:
            errbox.log("event_up_noe_label:"+inx,True)
            return
        tmpif=self.__labelInfo[inx]["info"]
        print(tmpif.INDEX,tmpif.NAME)
        # tmpif=self.labelInfoClass()
        if tmpif.TYPE=="output" and typ=="label":
            if tmpif.MODE=="io":
                print("set ["+tmpif.VALUE["ionum"]+"] to ["+tmpif.VALUE["value"]+"]")
                dev.ioset(tmpif.VALUE["ionum"],tmpif.VALUE["value"])
                rejsl["result"]="ok"
            elif tmpif.MODE=="ser1":
                serp.sendbytes(tmpif.VALUE)
                rejsl["result"]="ok"
            else:
                errbox.log("event_label_err:"+str(jsl),True)
        elif tmpif.TYPE=="echo" and typ=="echo":
            if tmpif.MODE=="io":
                print("set ["+tmpif.ECHOVALUE["ionum"]+"] to ["+tmpif.ECHOVALUE["value"]+"]")
                dev.ioset(tmpif.ECHOVALUE["ionum"],tmpif.ECHOVALUE["value"])
                rejsl["result"]="ok"
            elif tmpif.MODE=="ser1":
                serp.sendbytes(tmpif.ECHOVALUE)
                rejsl["result"]="ok"
            else:
                errbox.log("event_label_err:"+str(jsl),True)



    class labelInfoClass:
        def __init__(self):
            self.INDEX=""
            self.TYPE=""
            self.MODE=""
            self.VALUE=""
            self.NAME=""
            self.ECHOVALUE=""
            self.DEVSN=""
