"""
    Minipi专用联动控制中枢类
    区分与普通版本：
        带有IO控制
        带有屏幕控制

工程代号：回音链
2019年8月21日 03点30分
结构：
    包含三大类配置：
        SourceMode :    "io/get/serial"
        SourceValue:    "{iopin:3,value:1}"/"http://123/?action"/"x65x01x00"
        TargetMode :    "io/get/serial"
        TargetValue:    "..."
        EchoMode:       "io/get/serial"
        EchoValue:      "..."

    使用回音链后，会在指定通讯类型注册数据返回事件；
    当回收到的数据与指定的源触发值相同，则执行目标通讯类型和值；
    当某个目标的值发生改变，如果注册回音链的其他事件有回音触发，则将联动事件按照回音触发的模式给发送出去

模式：
    简易注册模式
    自定义编程模式
"""
from Armoury import sock
from Armoury import fso
from Armoury import errbox
from plug.API import label


class echolinkInfoClass:
    def __init__(self):
        """
        【临时标签储存结构】
        用于储存label与指向的GET的动作的储存结构
        """
        self.NAME=""
        self.LABELINDEX=""
        self.RMLABEKINDEX=""
        self.RMURL=""
        self.RMPORT=""


# 配置文件路径
ECHOLINKINI = "setting/EchoLinkSetting.ini"

# 设备组列表，保存整个组里面所有设备的序列号
DEVICELIST=[]

# 标签系统配置
__labelObject=label.labelClass
# 储存label的结构体，与label内部的同名变量不一样
__labelInfo={
        "labelindex" : echolinkInfoClass()
    }
__labelInfo.clear()


def startup(localLabelObj):
    """
    开机运行项目，使用回音链的初始化入口
    """
    global __labelObject,__labelInfo,ECHOLINKINI
    ECHOLINKINI = fso.get_propath("setting", "EchoLinkSetting.ini")
    __labelObject=localLabelObj

    # echolink label信息树
    __labelInfo={
        "labelindex" : echolinkInfoClass()
    }
    __labelInfo.clear()

    # 读取原有的echolink配置
    ra=fso.rallini(ECHOLINKINI)
    for itm in ra:
        __labelObject.addEvent(ra[itm]["label"],__event_loLabelUp)
        tmpinfo=echolinkInfoClass()
        tmpinfo.NAME=ra[itm]["name"]
        tmpinfo.LABELINDEX=ra[itm]["label"]
        tmpinfo.RMLABEKINDEX=ra[itm]["rmlabel"]
        tmpinfo.RMURL=ra[itm]["rmurl"]
        tmpinfo.RMPORT=ra[itm]["rmport"]
        __labelInfo[ra[itm]["label"]]=tmpinfo


def addEchoLinkGroup(devSN,rndKey):
    """
    将指定设备组成一个组；当指定为一个组的设备后，其echolink将共享所有标签信息
    ##############################
    devSN : 设备序列号
    rndkey ： 设备钥匙串
    """
    pass

def addEchoLinkRemote(name:str,localIndex:str,url:str,port:str,labelIndexRM:str):
    """
    【临时添加入口】
    添加远程的minipi客户端上的label
    """
    # name = 远程开灯
    # label = 8794
    # rmlabel = 9284
    # rmurl = 192.168.0.50
    # rmport = 7777
    global ECHOLINKINI,__labelInfo,__labelObject
    if __labelObject.getLabel(localIndex).NAME=="":
        return

    if name=="" or localIndex=="" or url=="" or port=="" or labelIndexRM=="":
        errbox.log("Args-err-in-echolink",True)
        return
    fso.wini(ECHOLINKINI,name,"name",name)
    fso.wini(ECHOLINKINI,name,"label",localIndex)
    fso.wini(ECHOLINKINI,name,"rmlabel",labelIndexRM)
    fso.wini(ECHOLINKINI,name,"rmurl",url)
    fso.wini(ECHOLINKINI,name,"rmport",port)
    __labelObject.addEvent(localIndex,__event_loLabelUp)
    tmpinfo=echolinkInfoClass()
    tmpinfo.NAME=name
    tmpinfo.LABELINDEX=localIndex
    tmpinfo.RMLABEKINDEX=labelIndexRM
    tmpinfo.RMURL=url
    tmpinfo.RMPORT=port
    __labelInfo[localIndex]=tmpinfo

def delEcholinkRemote(name:str):
    """
    【临时删除入口】
    删除已经建立的echolink remote链接

    """
    for itm in __labelInfo:
        if __labelInfo[itm].NAME==name:
            del __labelInfo[itm]
            break

def link(labelIndex:str,labelIndex2:str)->bool:
    """
    将两个标签继续link操作，自动判断input和output接口，如果两个都是output则返回false
    ***************************
    labelIndex/labelIndex2 ： 两个在组里面的标签
    """
    pass

def info()->list:
    """
    返回当前所有建立了echolink的信息
    ###############################
    return : [{}]
    """
    ll=[]
    for itm in __labelInfo:
        tmpjs={
            "name":__labelInfo[itm].NAME,
            "locallabel":__labelInfo[itm].LABELINDEX,
            "remotelabel":__labelInfo[itm].RMLABEKINDEX,
            "url":__labelInfo[itm].RMURL,
            "port":__labelInfo[itm].RMPORT
        }
        ll.append(tmpjs)
    return ll

def echolinkShow():
    """
    """
    for itm in __labelInfo:
        print("#######[]#######")
        print("# NAME:"+__labelInfo[itm].NAME)
        print("# LABELINDEX:"+__labelInfo[itm].LABELINDEX)
        print("# LABELINDEX:"+__labelInfo[itm].RMLABEKINDEX)
        print("# RMURL:"+__labelInfo[itm].RMURL)
        print("# RMPORT:"+__labelInfo[itm].RMPORT)
        print("# ")

def __event_loLabelUp(labelIndex:str):
    """
    当指定的label被触发，会回调到本函数。
    """
    print("EchoLink:",labelIndex)
    if labelIndex not in __labelInfo:
        return
    args={  "series":"minipi",
            "plug":"label",
            "action":str(__labelInfo[labelIndex].RMLABEKINDEX)
            }
    print("ECHOING..........")
    sock.jsonapi(__labelInfo[labelIndex].RMURL +":"+__labelInfo[labelIndex].RMPORT,
        args)








