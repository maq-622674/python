"""
插件调用的web功能
本文件是配合minipi下的插件调用网页类功能的模块，可以利用本模块修改页面路径
使用方式：
    1：修改区将插件名称修改为当前插件的名字
    2：使用 route 可以将指定的路径，本修改为动态修改，立即生效
    
"""
from Core.WWW import weblocal
from Core.Local import local
from Armoury import fso
import json

class webapi:
    PLUG_NAME=""
    def __init__(self,plugname):
        """
        """
        self.PLUG_NAME=plugname

    def getArg(self,tndobj,key:str,defaultvalue:str="")->str:
        """
        从tnd对象中获取请求参数
        """
        return tndobj.get_argument(key,defaultvalue)

    def get_args(self,tndobj)->dict:
        """
        获取所有 GET请求参数,仅仅获取?后面的请求参数
        """
        rjs={}
        for key in tndobj.request.arguments:
            rjs[key] = tndobj.get_arguments(key)[0]
        return rjs

    def get_body_json(self,tndobj)->dict:
        """
        一般用于post，获取post的内容
        """
        try:
            return json.loads(tndobj.request.body.decode())
        except:
            return {}

    def setCookie(self,tndobj,key:str,value:str):
        """
        设置cookie值
        \n tndobj : tornado request self object
        \n key : cookie的键名称
        \n value : 键值对的值，会自动加密
        \n pwd : 加密密文
        """
        tndobj.set_secure_cookie(key,value)


    def getCookie(self,tndobj,key:str)->str:
        """
        将指定的cookie的值读取出来，会自动将加密内容进行解密
        """
        if key not in tndobj.cookies:
            return ""
        return tndobj.get_secure_cookie(key).decode()

    def get_url(self,tndobj)->str:
        """
        获取访问进来的URL段
        """
        return tndobj.request.uri

    def route(self,url:str,ptrfun):
        """
        将指定访问链接添加函数回调
        url = <"" 或 "/"> ：将指向插件名称
        url = <"/xxx">      ：绝对路径链接
        url = <"xxx">       ：相对路径链接
        url = <"/*">        :特殊值，代表抢夺主页
        \n ptrfun(method,tornadoobj)
        """
        jwscls=weblocal.JWSCLS
        if url=="/" or url=="":
            jwscls.route("/"+self.PLUG_NAME,ptrfun)
            return
        if url=="/*":
            # 特殊值 /* 代表抢夺主页
            jwscls.route("/",ptrfun)
            return
        if url[:1]!="/":
            # 使用相对路径
            jwscls.route("/"+self.PLUG_NAME+"/"+url,ptrfun)
        else:
            # 使用绝对路径
            jwscls.route(url,ptrfun)

    def routeFiles(self,url:str,abs_folder:str):
        """
        添加静态文件路由
        如果为空，则默认添加 /File/<插件名> 的url
        如果前面有斜杠，则添加到url的绝对访问路径
        如果没有斜杠，则是默认添加到/File/plugname/
        """
        jwscls=weblocal.JWSCLS
        print("@@@@@@@@@@@@@@@@@@@@")
        print(url)
        if len(url)>1 and url[-1:]=="/":
            url=url[:-1]
        if url=="":
            url="/File/"+self.PLUG_NAME
        elif url[:1] != "/":
            # 如果不使用绝对路径符，则会使用相对路径，
            # 默认添加到/File/插件名后面
            url="/File/"+self.PLUG_NAME+"/"+url
        jwscls.route_file(url,abs_folder)


    def getOuterUrl(self)->str:
        """
        获取当前minipi的外网访问链接
        使用的转发服务器是LS服务器
        """
        from Core.Local import pigeon,local
        pgn=pigeon.pigeon("HPWEB")
        inis=pgn.info()
        pgnid="__HPWEB_"+local.MY_ID
        if pgnid not in inis:
            return ""
        return inis["common"]["server_addr"]+":"+inis[pgnid]["remote_port"]

    def getUploadFolder(self,filename:str="")->str:
        """
        获取上传文件夹的文件夹路径
        """
        fso.foldexist(local.FOLDER_TMP+"/upload_files/")
        return local.FOLDER_TMP+"/upload_files/"+filename
        