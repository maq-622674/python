"""
消息队列管理器
作者：TheOWL
2019年9月19日 23点52分

"""

from Armoury import fso

class msgInfoClass:
    def __init__(self):
        """
        """
        self.PRODUCE_NAME=""
        self.FUNCTION_NAME=""
        self.TIME=""
        self.MSG=""
        self.IS_READ=False

__msgList={
    "jimuti":[msgInfoClass()]
}
__msgList.clear()
HASMSG=[]

def add(produceName:str,functionName:str,msg:str):
    """
    创建或添加新的消息到队列中
    """
    global __msgList,HASMSG
    if produceName not in __msgList:
        __msgList[produceName]=[]
    tmpmsgif=msgInfoClass()
    tmpmsgif.PRODUCE_NAME=produceName
    tmpmsgif.FUNCTION_NAME=functionName
    tmpmsgif.TIME=fso.now()
    tmpmsgif.MSG=msg
    tmpmsgif.IS_READ=False
    __msgList[produceName].append(tmpmsgif)
    HASMSG.append(produceName + "." + functionName)


def get(produceName:str,functionName:str)->list:
    """
    获取当前产品的所有消息
    ##########################
    return : [{}]
    """
    rejs=[]
    if produceName not in __msgList:
        return rejs
    for itm in __msgList[produceName]:
        if functionName!="":
            if itm.FUNCTION_NAME==functionName:
                rejs.append({
                    "proname":itm.PRODUCE_NAME,
                    "funname":itm.FUNCTION_NAME,
                    "time":itm.TIME,
                    "msg":itm.MSG,
                    "isread":itm.IS_READ
                })
        else:
            rejs.append({
                    "proname":itm.PRODUCE_NAME,
                    "funname":itm.FUNCTION_NAME,
                    "time":itm.TIME,
                    "msg":itm.MSG,
                    "isread":itm.IS_READ
                })
    return rejs

def read(produceName:str,functionName:str)->dict:
    """
    读取还没读的消息，先进先出原则
    ################################
    return : {}
    """
    global HASMSG
    rejs={}
    if produceName not in __msgList:
        return rejs
    for itm in __msgList[produceName]:
        if functionName!="":
            if itm.FUNCTION_NAME==functionName and itm.IS_READ==False:
                rejs= {
                    "proname":itm.PRODUCE_NAME,
                    "funname":itm.FUNCTION_NAME,
                    "time":itm.TIME,
                    "msg":itm.MSG
                }
                itm.IS_READ=True
                break
        else:
            if itm.IS_READ==False:
                rejs={
                        "proname":itm.PRODUCE_NAME,
                        "funname":itm.FUNCTION_NAME,
                        "time":itm.TIME,
                        "msg":itm.MSG
                    }
                itm.IS_READ=True
                break
    if rejs=={}:
        HASMSG.remove(produceName + "." + functionName)
    return rejs


