import xlrd
import xlwt
from Armoury import fso


class excel:
    class excel_read:
        def __init__(self,filepath):
            # xlrd.Book.encoding="gbk"
            self.__excel_obj=xlrd.open_workbook(filepath)
            self.__maxrows=0
            self.__maxcolumns=0
            self.__nextrowindex=0
            # self.__opensheet=xlrd.open_workbook(filepath).sheet_by_name(1)

        def show_tables(self):
            """
            显示所有的表格
            return : []
            """
            return self.__excel_obj.sheet_names()
            # sheet = readbook.sheet_by_index(1) #索引的方式，从0开始
            # sheet = readbook.sheet_by_name('sheet2') #名字的方式

        def open_sheet(self,sheet_name):
            """
            打开指定名称的表格
            """
            print(str(type(sheet_name)))
            if str(type(sheet_name)) == "<class 'int'>":
                opensheet=self.__excel_obj.sheet_by_index(sheet_name)
            elif str(type(sheet_name)) == "<class 'str'>":
                opensheet=self.__excel_obj.sheet_by_name(sheet_name)
            self.__opensheet=opensheet
            self.__maxrows=opensheet.nrows
            self.__maxcolumns=opensheet.ncols

            
        def get_row(self,row_index):
            """
            获取第几行的数据,开始是从0开始
            """
            return self.__opensheet.row_values(row_index)
        
        def next_row(self):
            """
            """
            pass
        
        def get_rows(self,startrow=0):
            """
            一次性读取整个表格的内容，内容多的表格慎用
            return : [[]]
            """
            sheet_datas=[]
            for itm in range(startrow,self.__maxrows):
                sheet_datas.append(self.__opensheet.row_values(itm))
            return sheet_datas

        def get_titles(self):
            """
            获取第一行的文字作为标题
            """
            return self.get_row(0)

        def close(self):
            """
            关闭打开的表格文件
            """

        def add_sheet(self,sheet_name):
            """
            添加一个新的表
            """
            #打开一个excel
            writebook = xlwt.Workbook()
            #在打开的excel中添加一个sheet
            writebook.add_sheet(sheet_name)
    
    class excel_write:
        def __init__(self,filepath,sheet_name):
            """
            创建一个用于写的excel
            """
            self.__excel_obj = xlwt.Workbook()
            self.__opensheet=self.__excel_obj.add_sheet(sheet_name)
            self.__filepath=filepath

            # 自动确定宽度
            self.__col_width={"0":10}
            self.__col_width.clear()


        def write(self,row_index,col_index,value):
            """
            """
            self.__opensheet.write(row_index,col_index,str(value))

        def writeline(self,row_index,col_index,data_list,font_style=""):
            """
            写入一行数据，写入的数据需要是list格式，
            """
            row_start=row_index
            for itm in data_list:
                # 确定当前表格的数据的宽度
                colstr=str(col_index)
                vul=str(itm)
                if colstr in self.__col_width:
                    if len(vul.encode('utf-8'))>self.__col_width[colstr]:
                        self.__col_width[colstr]=len(vul.encode('utf-8'))
                else:
                    self.__col_width[colstr]=len(vul)
                # 写入数据
                if font_style=="":
                    self.__opensheet.write(row_start,col_index,vul)
                else:
                    self.__opensheet.write(row_start,col_index,vul,font_style)
                col_index+=1

        def font_style(self,str_color):
            """
            返回字体样式
            ******************
            return : xlwt obj
            """
            style = "font:colour_index "+str_color+";"
            return xlwt.easyxf(style)

        def writetable(self,row_index,col_index,table_list_list):
            """
            把一个含有两个list的数据写入一个excel中。
            ***********************
            return : no
            """
            row_start=row_index
            for li in table_list_list:
                col_start=col_index
                for itm in li:
                    self.__opensheet.write(row_start,col_start,str(itm))
                    col_start+=1
                row_start+=1

        def close(self):
            """
            保存关闭
            """
            for itm in self.__col_width:
                if int(self.__col_width[itm])>10:
                    self.__opensheet.col(int(itm)).width=256 * (int(self.__col_width[itm]) +3)
                else:
                    self.__opensheet.col(int(itm)).width=256 * 10

            self.__excel_obj .save(self.__filepath)

#   # 获取整行和整列的值（数组）  
#   rows = sheet2.row_values(3) # 获取第四行内容  
#   cols = sheet2.col_values(2) # 获取第三列内容  
#   print rows  
#   print cols  
   
#   # 获取单元格内容  
#   print sheet2.cell(1,0).value.encode('utf-8')  
#   print sheet2.cell_value(1,0).encode('utf-8')  
#   print sheet2.row(1)[0].value.encode('utf-8')  
     
  # 获取单元格内容的数据类型  
#   print sheet2.cell(1,0).ctype  


class checkon:
    def __init__(self,filepath,sheet_index=-1):
        """
        导入需要进行分析的excel表格
        """
        # 是否过滤周六
        self.__filter_saturday=True
        # 是否过滤周日
        self.__filepath=filepath
        # 是否存在特殊节日

        self.__check_year=2019
        self.__check_month=2

        self.__opensheet_index=sheet_index

        self.__special_days={"2019-02-04":"春节",
                            "2019-02-05":"春节",
                            "2019-02-06":"春节",
                            "2019-02-07":"春节",
                            "2019-02-08":"春节",
                            "2019-02-09":"春节",
                            "2019-02-10":"春节",
                            "2019-04-05":"清明节",
                            "2019-04-06":"清明节",
                            "2019-04-07":"清明节",
                            }
        self.__checkonlst={"张三":{"records":[] , 
                            "index":"abc123" , 
                            "checkon":[] }}
        self.__checkonlst.clear()

        # 立即生成考勤数据
        self.__get_origindata()


    def __get_origindata(self):
        """
        从源文件获取原始数据并进行数据初始化
        正常返回空字符串，遇到错误会返回错误字符串
        return : str_errmsg
        """
        excelobj=excel()
        xls=excelobj.excel_read(self.__filepath)
        if self.__opensheet_index<0:
            if len(xls.show_tables())>1:
                return "Multi_Sheet"
            else:
                self.__opensheet_index=0
        # 打开指定index的表格
        xls.open_sheet(self.__opensheet_index)
        # 获取第一行的数据，并作为默认标题
        tils=xls.get_titles()
        rowd=xls.get_rows(1)
        # 关键词
        u_index="员工编号"
        u_name="姓名"
        u_date="时间"
        # 关键词所在的列
        u_index_inx=-1
        u_name_inx=-1
        u_date_inx=-1

        cnt=0
        for itm in tils:
            if u_index==itm:
                u_index_inx=cnt
            if u_name==itm:
                u_name_inx=cnt
            if u_date==itm:
                u_date_inx=cnt
            cnt+=1

        if u_date_inx<0 or u_name_inx<0 or u_index_inx<0:
            print("EXCEL_TITLE_CHECK_ERROR")
            return "EXCEL_TITLE_CHECK_ERROR"

        # 将源文件的刷卡记录导入到总变量中
        for li in rowd:
            una=li[u_name_inx]
            if una!="":
                if una not in self.__checkonlst:
                    self.__checkonlst[una]={"records":[],
                                    "index":li[u_index_inx]}
                if fso.is_datetime(li[u_date_inx]):
                    self.__checkonlst[una]["records"].append(li[u_date_inx])

        # 以上为获取到原始记录的所有数据
        return ""

    def mutil_in_one(self):
        """
        调用这个函数后，会把名字带有数字的人都合并成一个人，
        例如张三、张三1、张三2，会合并成张三
        """
        usrs=[]
        tmp_checkonlist={}
        for usr in self.__checkonlst:
            for inx in range(0,10):
                usr=usr.replace(str(inx),"")
            if usr not in usrs:
                usrs.append(usr)


        for fusr in usrs:
            if fusr not in tmp_checkonlist:
                tmp_checkonlist[fusr]={"records":[],
                                    "index":"000"}
            for usr in self.__checkonlst:
                chkingusr=usr
                for inx in range(0,10):
                    usr=usr.replace(str(inx),"")
                if usr==fusr:
                    for itm in self.__checkonlst[chkingusr]["records"]:
                        tmp_checkonlist[fusr]["records"].append(itm)

        # 将tmp的值转移到checkonlist里面
        self.__checkonlst.clear()
        for usr in tmp_checkonlist:
            self.__checkonlst[usr]=tmp_checkonlist[usr]
        print("Multi User in One")
        


    def add_specialday(self,str_date,str_speday_name="假期"):
        """
        添加自定义的假日
        """
        self.__special_days[str_date]=str_speday_name


    def __checkin(self,int_year,
                    int_month,
                    filter_saturday=True,
                    filter_sunday=True,
                    filter_special=True
                    ):
        """
        开始将原始刷卡记录变成考勤记录
        """
        # # 将刷卡记录变成考勤数据,下面循环是将已经刷卡的数据先导入checkon
        for usr in self.__checkonlst:
            # 每个人创建一个新的表，
            # checkon:{ "date_str":{ "first":"" , "last":"" } }
            if "checkon" not in self.__checkonlst[usr]:
                self.__checkonlst[usr]["checkon"]={}
            for rec in self.__checkonlst[usr]["records"]:
                r_date=rec.split(" ")[0]
                if r_date not in self.__checkonlst[usr]["checkon"]:
                    self.__checkonlst[usr]["checkon"][r_date]={}
                # 如果这个日期之间没有数据，则插入现在的数据进去，否则无法进行对比
                if len(self.__checkonlst[usr]["checkon"][r_date])==0:
                    self.__checkonlst[usr]["checkon"][r_date]["first"]=rec
                    self.__checkonlst[usr]["checkon"][r_date]["last"]=rec
                    self.__checkonlst[usr]["checkon"][r_date]["remark"]="ok"
                # 替代最早时间
                if fso.caleseconds(rec,self.__checkonlst[usr]["checkon"][r_date]["first"])>0:
                    self.__checkonlst[usr]["checkon"][r_date]["first"]=rec
                # 替代最晚时间
                if fso.caleseconds(rec,self.__checkonlst[usr]["checkon"][r_date]["last"])<0:
                    self.__checkonlst[usr]["checkon"][r_date]["last"]=rec


        checking_year=int_year
        checking_month=int_month
        # 指定的这个月从1号开始检查所有人的所有刷卡记录
        dsim=fso.daysinmonth(checking_year,checking_month)
        for day in range(1,dsim+1):
            chkingdate=str(checking_year)+"-"+str(checking_month).zfill(2)+"-"+str(day).zfill(2)
            for usr in self.__checkonlst:
                if filter_special and chkingdate in self.__special_days:
                    self.__checkonlst[usr]["checkon"][chkingdate]={}
                    self.__checkonlst[usr]["checkon"][chkingdate]["first"]="--"
                    self.__checkonlst[usr]["checkon"][chkingdate]["last"]="--"
                    self.__checkonlst[usr]["checkon"][chkingdate]["remark"]=self.__special_days[chkingdate]
                elif filter_saturday and fso.week(chkingdate)==5:
                    self.__checkonlst[usr]["checkon"][chkingdate]={}
                    self.__checkonlst[usr]["checkon"][chkingdate]["first"]="--"
                    self.__checkonlst[usr]["checkon"][chkingdate]["last"]="--"
                    self.__checkonlst[usr]["checkon"][chkingdate]["remark"]="周六放假"
                elif filter_sunday and fso.week(chkingdate)==6:
                    self.__checkonlst[usr]["checkon"][chkingdate]={}
                    self.__checkonlst[usr]["checkon"][chkingdate]["first"]="--"
                    self.__checkonlst[usr]["checkon"][chkingdate]["last"]="--"
                    self.__checkonlst[usr]["checkon"][chkingdate]["remark"]="周日放假"
                else :
                    if chkingdate not in self.__checkonlst[usr]["checkon"]:
                        # 这个字符串的日期不在考勤表里面，则判定为未刷卡
                        self.__checkonlst[usr]["checkon"][chkingdate]={}
                        self.__checkonlst[usr]["checkon"][chkingdate]["first"]="未刷卡"
                        self.__checkonlst[usr]["checkon"][chkingdate]["last"]="未刷卡"
                        self.__checkonlst[usr]["checkon"][chkingdate]["remark"]="未刷卡"
        # 上面得出的是刷了卡的数据，只刷了一次或者没有刷卡的天数并没有添加，则进行判断

    def __checkout(self,output_filepath=""):
        """
        导出文件,如果导出文件路径为空，则会在文件路径生成一个“考勤-yyyy-mm.xls”的文件
        ****************************
        return : null
        """
        restr=["星期一","星期二","星期三","星期四","星期五","星期六","星期日"]
        warning_msg=["未刷卡",]
        if output_filepath=="":
            fp=fso.get_file_extension(self.__filepath)
            fp=self.__filepath.replace(fp,"") + "考勤-" + fso.datestr() + ".xls"
            output_filepath=fp.replace("\\","/")

        print(output_filepath)

        excelobj=excel()
        wxls=excelobj.excel_write(output_filepath,"每日记录")
        wxls.writeline(0,0,["编号","姓名","日期","开始打卡","结束打卡","备注"])
        red_style=wxls.font_style("red")
        green_style=wxls.font_style("green")
        blue_style=wxls.font_style("blue")
        next_color=[green_style,blue_style]
        color_inx=1
        startrowinx=1
        for usr in self.__checkonlst:
            tmpchkrec=fso.sort_keys(self.__checkonlst[usr]["checkon"])
            for dat in tmpchkrec:
                if self.__checkonlst[usr]["checkon"][dat[0]]["remark"] in warning_msg:
                    #这行数据的备注消息是警告消息
                    wxls.writeline(startrowinx,0,[self.__checkonlst[usr]["index"],
                                                usr,
                                                dat[0] + "  "+fso.week(dat[0],restr),
                                                self.__checkonlst[usr]["checkon"][dat[0]]["first"],
                                                self.__checkonlst[usr]["checkon"][dat[0]]["last"],
                                                self.__checkonlst[usr]["checkon"][dat[0]]["remark"]
                                                ],red_style)
                else:
                    wxls.writeline(startrowinx,0,[self.__checkonlst[usr]["index"],
                                                usr,
                                                dat[0] + "  "+fso.week(dat[0],restr),
                                                self.__checkonlst[usr]["checkon"][dat[0]]["first"],
                                                self.__checkonlst[usr]["checkon"][dat[0]]["last"],
                                                self.__checkonlst[usr]["checkon"][dat[0]]["remark"]
                                                ],next_color[color_inx])
                startrowinx+=1
            # 交叉颜色
            color_inx=1-color_inx
        wxls.close()

    def excel_out(self,int_year,int_month,
                    out_filepath="",
                    filter_saturday=True,
                    filter_sunday=True,
                    filter_special=True
                    ):
        """
        开始生成文件
        """
        self.__checkin(int_year,
                        int_month,
                        filter_saturday,
                        filter_sunday,
                        filter_special)
        self.__checkout(out_filepath)

# check_mon=2
# for usr in checkonlst:
#     for dat in checkonlst[usr]["checkon"]:
#         chkingdate="2019" + str(check_mon).zfill(2) 


chkobj=checkon("C:\\Users\\TheOWL\\Documents\\WeChat Files\\hgmmym\\FileStorage\\File\\2019-03\\记录\\新建文件夹 (2)\\2.xls")
chkobj.add_specialday("2019-02-01","春节增加")
chkobj.add_specialday("2019-02-11","春节增加")
chkobj.mutil_in_one()
chkobj.excel_out(2019,2)
# chkobj.checkin_out(2019,)
# 检查只有一次刷卡记录的情况

        
            

 





