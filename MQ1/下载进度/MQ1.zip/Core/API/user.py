
#################################################################
# Jimuti Plug : user
# CreateTime : 2020-06-14 23:26:29
# Author : Jimuti-Mgmt
# Setting : set "pathpysrc" with this file path in info.json
# Function format :
#   def plug_user_(dict_arg,return_dict_arg):
#       # use [] to set api argus
#       ["arg1","arg2"]
#       return_dict_arg["result"]="ok"
#################################################################

from Core.Local import local

class LOADUSERHOME:
    """
    用户目录控制,插件不允许在初始化时调用函数，否则无法获取账户名与目录
    """
    def __init__(self,ptrfun:callable=None):
        """
        创建初始化完毕事件；
        当本类的用户名与插件名不为空的时候，会产生一次初始化完毕事件
        函数格式  ptrfun()
        """
        self.__account=""
        self.__plugname=""
        # 触发过初始化事件后，本变量为真，防止重复触发初始化事件
        self.__hasloadinit=False
        self.__ptrfun_initfinish=callable
        self.__ptrfun_initfinish=None
        self.__ptrfun_initfinish=ptrfun
        

    def getHome(self,subpath:str=""):
        """
        获取插件主目录
        """
        if subpath=="":
            return local.FOLDER_USER + "/" + self.__account+"/"+self.__plugname
        else:
            subpath=subpath.replace("\\","/")
            if subpath[:1]!="/": subpath="/"+subpath
            return local.FOLDER_USER + "/" + self.__account+"/"+self.__plugname+subpath

    def getHomeSize(self)->int:
        """
        获取整个空间的文件夹大小
        return : int
        """
        return 1
    
    def nowAccount(self)->str:
        """
        获取当前操作的用户账号
        """
        return self.__account

    def loadUser(self,account:str):
        """
        加载使用账号，本函数仅供插件管理器使用
        """
        self.__account=account
        self.__event_initfinish()

    def loadPlugName(self,plugname:str):
        """
        加载插件名称，本函数仅供插件管理器使用
        """
        self.__plugname=plugname
        self.__event_initfinish()

    def __event_initfinish(self):
        """
        事件入口：
        当本类的账号与插件名被插件管理器加载完毕后。进入本事件
        """
        if self.__account!="" and self.__plugname!="" and not self.__hasloadinit and self.__ptrfun_initfinish!=None:
            self.__hasloadinit=True
            self.__ptrfun_initfinish()
            