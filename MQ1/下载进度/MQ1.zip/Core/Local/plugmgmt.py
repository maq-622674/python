"""
插件管理器
TheOwl
2019年1月22日16:21:22

用于动态管理外部插件与minipi项目的控制

相关结构：
文件夹：
    plug/plug_name

每个脚本拥有自己的文件夹
    plugs/testplug

    插件名称为文件名
    testplug.py
    /py_folder
    index.html
    /html_folder

设置里面标准样式：
    [testplug]
    json_scr = /home/jimuti/minipi/plugs/Apps/testplug/info.json


python脚本特殊函数：
    from Armoury import xxx : 从Armoury调用指定类函数

命令集：
    repair ： 修复插件路径配置，主要应用于minipi更换文件夹后路径错误

0.3版本 info.json 文档参数
    # 旧接口文档
    {   "plugname": "aliyunddns",       #！必填
        "title": "无标题",              #选填
        "width": "500",                 #选填
        "need": "无",                   #选填
        "author": "积木体",             #选填
        "instuction": "未添加说明信息"  #选填
    }

    # 新增部分
    pathindex : "index.html" ,    指向主页，当访问127.0.0.1 / plugname 会访问当前插件目录下的主页文件
    pathfiles : "Files" ,    指向静态文件目录，路径为127.0.0.1/Files/  plugname /js/xxx
    pathhtmls : "HTML" ,    指向html模板文件夹,路径为127.0.0.1/plugname/  user/xxx
    pathpysrc : "plugname.py" ,    指向后端脚本文件
    pathuser  : "user.html" ,    指向插件操控页面的模板文件
    routeindex : "/",    网页路由设置，设置该路由后，可将指定的url改成当前插件指向的目标
    routefiles : "/",    静态文件路由设置，设置该路由后，可将当前的静态文件路由到指定路径
    pathautojs : "startup.js"   当住用户控制页面打开时自动加载指定脚本


1： 插件必须包含info.json,并且最少参数为{"plugname":"<plugname>"}
2: 如果设置了路由参数，必须设置页面路径
"""
import os
import shutil
import json
from Core.Local import local
from Armoury import fso
from Armoury import sock
from Core.WWW import weblocal
import traceback

# 允许调用的模块的名称
__allow_import_keyword = ["import fso",
                          "import sock",
                          "import formatfun",
                          "import datetime",
                          "import time",
                          "import queuemsg",
                          "import Thread",
                          "import shutil",
                          "import os",
                          "import Image",
                          "import json",
                          "import sqlib",
                          "import webapi",
                          "import sys",
                          "from plug.",
                          "from Armoury "]

# 特殊函数名称，接口函数使用以下函数名称会执行对应的功能
__specialfunction_names = [
                        "looping",      # 线程循环执行
                        "import_path_head", # 由于已经使用该名称用于导入模块，所以不允许用作函数名
                        "userhome",     # 保存用户空间的变量名称
                        ]


def init():
    """
    初始化插件功能，启动常运行脚本，把脚本插入到接口中
    """
    loadplug()
    # 命令功能，上传插件文件完毕后进行加载
    JWSCLS=weblocal.JWSCLS
    JWSCLS.load_plug("plug","loadplug", api_loadplugzip, "plugname","account")
    JWSCLS.load_plug("plug","alllist", api_plugalllist,"account")
    JWSCLS.load_plug("plug","html", api_plughtml, "plugname","account")
    JWSCLS.load_plug("plug","info", api_pluginfo, "plugname","account")
    JWSCLS.load_plug("plug","list", api_pluglist,"account")
    JWSCLS.load_plug("plug","uninstall", api_pluguninstall, "plugname","account")
    JWSCLS.load_plug("plug","test", api_testapi)

    JWSCLS.load_plug("web", "port",plug_web_port,"port")
    JWSCLS.load_plug("web", "settingget", plug_web_settingget, "name", "defaultvalue" , "account")
    JWSCLS.load_plug("web", "settinggets",plug_web_settinggets, "name" , "account")
    JWSCLS.load_plug("web", "settingset",plug_web_settingset, "name", "value" , "account")
    JWSCLS.load_plug("web", "timeout",plug_web_timeout,"timeout", "account")

    JWSCLS.load_plug("web","accountadd",plug_web_accountadd,"fromaccount","newaccount","pwd","confirmpwd")
    JWSCLS.load_plug("web","accountchange",plug_web_accountchange,"account","okw","nkw")
    JWSCLS.load_plug("web","accountdel",plug_web_accountdel,"account","uid")
    JWSCLS.load_plug("web","accountshow",plug_web_accountshow)
    print("Start Plug API")

def create(account:str,plugname:str)->bool:
    """
    在指定账户下创建一个空的新的plug插件应用，方便新应用开发
    \n 如果指定账户不存在，或者应用名称重复，则创建失败
    """
    ll=get_plug_accounts()
    if account not in ll:
        print("指定账户不存在:"+account)
        return False
    ll=get_plug_allitems(account)
    if plugname in ll:
        print("指定插件名称存在："+plugname)
        return False
    # 创建新文件夹
    plugfold=get_plug_folder(plugname)
    usrpfold=getUserFolder(account,plugname)
    fso.foldexist(usrpfold)
    fso.foldexist(plugfold)
    plugjson=get_plug_folder(plugname,True)
    info=("""
{
    "plugname":"__PLUGNAME",
    "title":"无标题",
    "width":"500",
    "need":"无",
    "author":"积木体",
    "instuction":"未添加说明信息",
    "pathindex":"",
    "pathfiles":"",
    "pathhtmls":"",
    "pathpysrc":"",
    "pathuser":"",
    "pathautojs":"",
    "routeindex":"",
    "routefiles":""
}
        """)
    info=info.replace("__PLUGNAME",plugname)
    # txt=json.dumps(info,ensure_ascii=False)
    fso.wtxt(plugjson,info ,False)
    # fso.wini(local.PLUGSETTING_INI,plugname,"pathinfo",plugname+"/info.json")
    # 创建新的python文件，0.3版本后文件名称已经不需要固定，但是创建模板供用户参考
    pypath=plugfold + "/"+plugname+".py"
    pycode=("""
#################################################################
# Jimuti Plug : __PLUGNAME
# CreateTime : __NOW
# Author : Jimuti-Mgmt
# Setting : set "pathpysrc" with this file path in info.json
# Function format :
#   def plug___PLUGNAME_(dict_arg,return_dict_arg):
#       # use [] to set api argus
#       ["arg1","arg2"]
#       return_dict_arg["result"]="ok"
#################################################################
    """)
    pycode=pycode.replace("__PLUGNAME",plugname).replace("__NOW",fso.now())
    fso.wtxt(pypath,pycode,False)
    return True
    

def restart():
    """
    重启插件模块组
    """
    global LOADLIST
    LOADLIST.clear()

    init()
"""
############################################
#   接口命令集
############################################
"""
def api_plughtml(jsl, rejsl):
    """
    获取指定插件的html信息
    \n[plugname]
    """
    plugna = jsl["plugname"]
    account_name=jsl["account"]
    rejsl["result"] = "ok"
    rejsl["html"] = get_plug_html(plugna,account_name)
    rejsl["title"]=get_plug_info(plugna,account_name).TITLE


def api_pluginfo(jsl, rejsl):
    """
    获取指定插件的json信息
    [plugname]
    """
    plugna = jsl["plugname"]
    account_name=jsl["account"]
    pinfo =get_plug_info(plugna,account_name)
    rjs=pinfo.getInfo()
    if len(rjs) == 0:
        rejsl["result"] = "false"
        return
    rejsl["result"] = "ok" 
    for itm in rjs:
        rejsl[itm]=rjs[itm]


def api_pluglist(jsl, rejsl):
    """
    获取已经启用的插件名称
    []
    """
    account_name=jsl["account"]
    # lst = get_plug_items()
    lst=get_plug_allitems(account_name)
    rejsl["list"] = lst
    rejsl["result"] = "ok"


def api_plugalllist(jsl, rejsl):
    """
    获取所有已经安装的插件的名称
    []
    """
    rejsl["list"]=[]
    account_name=jsl["account"]
    lst = get_plug_allitems(account_name)
    onrunninglst=get_plug_items()
    for itm in lst:
        pinfo=get_plug_info(itm,account_name)
        if itm in onrunninglst:
            rejsl["list"].append({
                "plugname":itm,
                "enable":"true" , 
                "title":pinfo.TITLE
                })
        else:
            rejsl["list"].append({  
                "plugname":itm,
                "enable":"false", 
                "title":pinfo.TITLE
                })
    rejsl["result"] = "ok"

def api_loadplugzip(jsl, rejsl):
    """
    加载自定义插件，传入参数为 文件名.后缀
    目前仅支持linux下的apache2的上传系统
    当上传文件完毕后，html需要向本接口发送loadplugzip命令来进行加载
    [plugname]
    """
    plugname = jsl["plugname"]
    account_name = jsl["account"]
    print("########[ LOADZIP  ]#######")
    print("plugname" , plugname)
    print("account:" , account_name)
    plugfile = fso.get_propath("tmp","/upload_files/"+plugname)
    print("LOADING PLUG:"+plugfile,True)
    if loading_plugzip(plugfile,account_name):
        print("LOAD SUCC",True)
        rejsl["result"] = "ok"
        # 安装插件完毕，程序会进行软重启
        # jsapi.REQ_RESTART = True
        restart()
    else:
        print("LOAD ERR",True)
        rejsl["result"] = "false"

    

def api_testapi(jsl, rejsl):
    """
    测试api是否开通用
    []
    """
    print("show imports")
    show_imports()
    print("#########################")
    rejsl["result"] = "ok"


def api_pluguninstall(jsl, rejsl):
    """
    卸载已经安装的插件
    """
    plugna = jsl["plugname"]
    account_name=jsl["account"]
    print("into uni-plug:"+plugna,True)
    plugini=get_fold(account_name,True)
    plugfold = get_fold(account_name + "/Apps/"+plugna)
    if os.path.exists(plugfold):
        # 删除app文件夹
        shutil.rmtree(plugfold)
    fso.item_delini(plugini, "local", "enable_list", plugna)
    fso.delini(plugini, plugna)
    # 删除完毕需要进行软重启以取消接口的调用
    rejsl["result"] = "ok"
    # jsapi.REQ_RESTART = True
    restart()


"""
# [     end     ] ##########################
############################################
"""

def show_imports():
    """
    打印当前引用的模块
    """
    print(dir())
    for itm in dir():
        print(itm)

def show_plugs_apis():
    """
    返回当前所有已经加载的插件和接口函数
    return : obj
    """
    global jsapi
    return jsapi.show_plugapis()


def get_plug_items()->list:
    """
    获取当前正在启用的插件名称
    \n 来源于enable_list 内的允许启动的插件名称
    return : list[]
    """
    # lst = fso.item_listini(local.PLUG_SETTINGINI, "local", "enable_list")
    lst = []
    plug_js = show_plugs_apis()
    for itm in plug_js:
        lst.append(itm)
    return lst


def get_plug_allitems(account_name:str)->list:
    """
    获取所有插件名称，包括未启用的
    return : list[]
    """
    lst = []
    accounts=get_plug_accounts()
    for usr in accounts:
        foldusr=fso.appfold("user/"+usr)
        if not os.path.exists(foldusr): return lst
        for itm in os.listdir(foldusr) :
            pth=foldusr + "/" +itm
            if os.path.isdir(pth):
                lst.append(itm)
    return lst
    # plugini=get_fold(account_name,True)
    # for itm in fso.rallini(plugini):
    #     if itm != "local":
    #         lst.append(itm)
    # return lst


class plugInfoClass:
    """
    储存插件info信息的类
    """
    def __init__(self,plugname:str,infojs:dict):
        """
        将info文档内的dict读出后，转化成js然后送入infojs参数中即可初始化

        """
        self.PLUGNAME=plugname
        if plugname=="":
            return
        self.TITLE=infojs.get("title","")
        self.WIDTH=infojs.get("width","500")
        self.NEED=infojs.get("need","无")
        self.AUTHOR=infojs.get("author","未公布")
        self.INSTRUCTION=infojs.get("instruction","插件作者并未填写该插件的介绍内容")
        self.PATHINDEX=infojs.get("pathindex","")
        self.PATHFILES=infojs.get("pathfiles","")
        self.PATHHTMLS=infojs.get("pathhtmls","")
        self.PATHPYSRC=infojs.get("pathpysrc","")
        self.PATHUSER=infojs.get("pathuser","")
        self.ROUTEINDEX=infojs.get("routeindex","")
        self.ROUTEFILES=infojs.get("routefiles","")
        self.PATHAUTOJS=infojs.get("pathautojs","")
        

    def getJson(self)->dict:
        """
        将当前信息类的所有属性转化成dict并返回
        \n 所有信息会返回，包括空键值对
        """
        tmpjs={}
        tmpjs["title"]=self.TITLE
        tmpjs["width"]=self.WIDTH
        tmpjs["need"]=self.NEED
        tmpjs["author"]=self.AUTHOR
        tmpjs["instruction"]=self.INSTRUCTION
        tmpjs["pathindex"]=self.PATHINDEX
        tmpjs["pathfiles"]=self.PATHFILES
        tmpjs["pathhtmls"]=self.PATHHTMLS
        tmpjs["pathpysrc"]=self.PATHPYSRC
        tmpjs["pathuser"]=self.PATHUSER
        tmpjs["routeindex"]=self.ROUTEINDEX
        tmpjs["routefiles"]=self.ROUTEFILES
        tmpjs["pathautojs"]=self.PATHAUTOJS
        return tmpjs

    def getInfo(self)->dict:
        """
        返回当前信息的有效数据，如果键值对额值为空，则不会包含在内
        """
        tmpjs={}
        tmpjs["title"]=self.TITLE
        tmpjs["width"]=self.WIDTH
        tmpjs["need"]=self.NEED
        tmpjs["author"]=self.AUTHOR
        tmpjs["instruction"]=self.INSTRUCTION
        if self.PATHINDEX!="":
            tmpjs["pathindex"]=self.PATHINDEX
        if self.PATHFILES!="":
            tmpjs["pathfiles"]=self.PATHFILES
        if self.PATHHTMLS!="":
            tmpjs["pathhtmls"]=self.PATHHTMLS
        if self.PATHPYSRC!="":
            tmpjs["pathpysrc"]=self.PATHPYSRC
        if self.PATHUSER!="":
            tmpjs["pathuser"]=self.PATHUSER
        if self.ROUTEINDEX!="":
            tmpjs["routeindex"]=self.ROUTEINDEX
        if self.ROUTEFILES!="":
            tmpjs["routefiles"]=self.ROUTEFILES
        if self.PATHAUTOJS!="":
            tmpjs["pathautojs"]=self.PATHAUTOJS
        return tmpjs


def get_plug_info(plugname,account_name)->plugInfoClass:
    """
    获取插件详细信息,主要是获取脚本的json
    \n 读取用户配置文件内的所有插件的info文件路径，如果检查info文件存在，则添加到返回的字典内。
    \n 所有禁用的启用的插件都会被返回
    **********************
    return :{ title , width , need , author ,instuction ,    
    pathindex ,pathfiles ,pathhtmls ,pathpysrc ,pathuser  
    ,routeindex ,routefiles 
    pathautojs 
    """
    plugini=get_plug_folder(plugname,True)
    if not os.path.exists(plugini):
        return  plugInfoClass("",{})
    f = open(plugini, "r", encoding="utf-8")
    jstxt = f.read()
    f.close()
    try:
        jsobj = json.loads(jstxt)
    except:
        print("[PLUG-MGMT]:read infojs error",True)
        return plugInfoClass("",{})
    tmpcls=plugInfoClass(plugname,jsobj)
    return tmpcls


def get_plug_html(plugname, account_name)->str:
    """
    获取插件详细信息,主要是获取脚本的html
    info.json 指向： pathuser
    return :string
    """
    print("read html sources")
    foldpath=get_plug_folder(plugname)
    print(foldpath)
    filename=get_plug_info(plugname,account_name).PATHUSER
    if filename=="":
        return ""
    usrindex = foldpath + "/" + filename
    print(usrindex)
    if not os.path.exists(usrindex):
        print("HTML PATH Not Exist:",infopth)
        return ""
    f = open(usrindex, "r", encoding="utf-8")
    htmltxt = f.read()
    f.close()
    print(htmltxt)
    return htmltxt

def get_plug_accounts()->list:
    """
    获取所有账户
    获取user文件夹下的所有文件夹，文件夹为账户名称
    """
    ll=[]
    folds=os.listdir(local.FOLDER_USER)
    for itm in folds:
        if os.path.isdir(local.FOLDER_USER + "/" + itm):
            ll.append(itm)
    return ll


def loadplug():
    """
    开机初始化函数
    加载已经导入的脚本文件
    """
    global LOADLIST
    print("#######[ DEBUGING ]#######")
    print("")
    print("LOADING PLUG......")
    JWSCLS=weblocal.JWSCLS
    # 递归所有用户：plugs的Home下
    accounts=get_plug_accounts()
    for act in accounts:
        # 储存特殊函数的列表，主要包含:
        # 是否包含启动头函数
        print("Checking Account["+act+"]")
        # 在0.3.14版本后 ， info作为必要配置文件，所有配置将直接在info.json进行读取
        # info.json所在的目录将默认成为插件主目录
        actplugs=getUserPlugs(act,True)
        print("Found Plug :"+str(actplugs))
        for plugname in actplugs:
            if plugname != "":
                print("Load account ["+act+"] ["+plugname+"]")
                plugfolder=get_plug_folder(plugname) + "/"
                infojs=get_plug_folder(plugname,True)
                if os.path.exists(infojs):
                    with open(infojs,"r",encoding="utf-8") as f:
                        ijs=json.loads(f.read())
                    # 加载python后端脚本
                    pysrc=ijs["pathpysrc"]
                    if pysrc!="":
                        # 这个插件有后台脚本
                        pypath=plugfolder+ pysrc
                        print("Python : "+pypath)
                        if os.path.exists(pypath):
                            # 脚本文件存在，继续加载
                            print("Load Python ["+plugname+"]")
                            __add_normalfunctions(act,plugname,pypath)
                            __add_importhead(act,plugname,pypath)
                    # # 加载静态文件夹
                    # filessec=ijs.get("pathfiles","")
                    # if filessec!="":
                    #     fpath=plugfolder+filessec
                    #     if os.path.exists(fpath):
                    #         print("Load Files ["+plugname+"]")
                    #         web.addFileFolderRoute(plugname,fpath)
                    #         # 检查是否需要修改文件url路径
                    #         filesurl=ijs.get("routefiles","")
                    #         if filesurl!="":
                    #             print("Route Files Page ["+plugname+"]")
                    #             web.addFileFolderRoute(filesurl,fpath)
                    # 加载主页文件
                    # indexsrc=ijs.get("pathindex","")
                    # if indexsrc!="":
                    #     # 这个插件有主页页面
                    #     indexpath=plugfolder+ indexsrc
                    #     if os.path.exists(indexpath):
                    #         # 首页文件存在，继续加载
                    #         print("Load Index ["+plugname+"]")
                    #         web.addRoute(plugname,indexpath)
                    #         # 检查路由设置
                    #         routeurl=ijs.get("routeindex","")
                    #         if routeurl!="":
                    #             # 该插件申请修改访问页面
                    #             print("Route Index Page : "+routeurl)
                    #             web.addRoute(routeurl,indexpath)
                else:
                    # info.json 不存在，该插件作为基础件处理
                    print("["+plugname+"]:info.json NOE")

                            
        
    # 上面的函数已经将所有用户的所有函数名称、import结构、特殊函数名全给读出来了
    # 下面是开始调用
    for act in accounts:
        __loading_py_functions(act)
    print("Load Finish")

# 插件所调用的所有信息，包括文件名称，文件接口，接口地址，需要的参数
LOADLIST={"account_name":
            {
                "testplug":{
                    "import_path_head":"import a.b.c",
                    "plug_testplug_echo":       # def 后面的函数名
                    {
                        "plugname": "testplug", 
                        "action": "echo",
                        "functionname": "plug_testplug_echo", 
                        "filterlist": ["name", "id"]
                    },
                    "looping":"<funs_addr>",
                    "userhome":"varname"    # 在调用user是进行初始化类后，变量的名称将会保存在这，如果没发现则直接没有这个键值对
                }
            }
        }
LOADLIST.clear()

def __add_normalfunctions(account,str_chkingplna,str_py_file:str):
    """
    将python里面的普通接口函数添加到loadlist里面去
    \n **************************
    \n 当前加载的账户
    \n str_chkingplna : 当前加载的插件名称
    \n str_py_file : 需要进行引用的python主文件
    \n return : null
    """
    global LOADLIST
    filterlist = ""
    scr = open(str_py_file, "r",encoding="utf-8")
    ra = scr.read()
    scr.close()
    if account not in LOADLIST:
        LOADLIST[account]={}
    if str_chkingplna not in LOADLIST[account]:
        LOADLIST[account][str_chkingplna]={}
    if "import_path_head" not in LOADLIST[account][str_chkingplna]:
        LOADLIST[account][str_chkingplna]["import_path_head"]=[]
    # 将当前的脚本写入到import路径
    importscr = "from plug." + str_chkingplna + " import " + str_chkingplna
    LOADLIST[account][str_chkingplna]["import_path_head"].append(importscr)

    for line in ra.split("\n"):
        line = line.strip(" ")
        if line[:4] == "def ":
            # 找到以def开头的函数开始
            fun_na = line.replace(
                "def ", "").split("(")[0].strip(" ")
            if fun_na in __specialfunction_names:
                # 如果这个函数名称在特殊函数名称表里面，则暂时不做处理
                pass
            else:
                # 如果找到的都不是关键词函数，则统一按照接口函数处理
                exist_fun = True     # 是否存在符合规范的可以调用的函数名
                fun_nas = fun_na.split("_", 2)
                if len(fun_nas) != 3:
                    print("[!X!]Function Name ERR!:"+fun_na)
                    exist_fun = False
                else:
                    plugtitle = fun_nas[0]
                    plugname = fun_nas[1]
                    plugact = fun_nas[2]
                    if plugtitle != "plug":
                        print("[!X!]PLUG NAME ERR:"+fun_na)
                        exist_fun = False
                    elif plugname != str_chkingplna:
                        print("[!X!]FUNCATION NAME ERR:"+fun_na)
                        exist_fun = False
                    elif plugact == "":
                        print("[!X!]ACTION ERR:"+fun_na)
                        exist_fun = False
                if exist_fun:
                    # 函数检查完毕，然后需要进行预加载。如果找到了符合要求的接口函数，
                    # 则会把脚本本身import到插件管理器中，供以后调用
                    filterlist = fun_na
                    # 添加完毕后，后面的行数在遇到函数之前如果遇到开头是[的，则判定为过滤列表
                    LOADLIST[account][str_chkingplna][fun_na] = {"plugname": str_chkingplna,
                                                                "action": plugact,
                                                                "functionname": fun_na,
                                                                "filterlist": []}
                    # print("Load Plug:"+fun_na,True)
        if filterlist != "" and line[:1] == "[":
            # 进入过滤列表，主要是针对[args]进行加载
            # 暂时不允许列表分行
            flst = []
            line = line.replace("[", "").replace("]", "").replace(
                "\"", "").replace(",", " ")
            for arg in line.split(" "):
                if arg != "":
                    flst.append(arg)
            LOADLIST[account][str_chkingplna][filterlist]["filterlist"] = flst
            filterlist = ""
        if ".LOADUSERHOME(" in line.replace(" ","") and line.replace(" ","")[:1]!="#":
            # 特殊函数,在插件user下，LOADUSERHOME是用户文件夹的初始化类
            # 发现这条语句，则将变量名称保存到LOADLIST键值对中
            LOADLIST[account][str_chkingplna]["userhome"]=line.split("=")[0]

def __add_importhead(account,str_chkingplna,str_py_file):
    """
    将送入的python文件的import继续解析。主要是读取import 的对象，并改成适用于后端的路径
    """
    global LOADLIST
    scr = open(str_py_file, "r",encoding="utf-8")
    ra = scr.read()
    scr.close()
    # 初始化储存结构
    if account not in LOADLIST:
        LOADLIST[account]={}
    if str_chkingplna not in LOADLIST[account]:
        LOADLIST[account][str_chkingplna]={}
    if "import_path_head" not in LOADLIST[account][str_chkingplna]:
        LOADLIST[account][str_chkingplna]["import_path_head"]=[]
    # 将当前的脚本写入到import路径
    importscr = "from plug." + str_chkingplna + " import " + str_chkingplna
    if importscr not in LOADLIST[account][str_chkingplna]["import_path_head"]:
        LOADLIST[account][str_chkingplna]["import_path_head"].append(importscr)
    # 判断是否引用了官方类函数库
    # from Armoury import sock
    lastline=""
    for line in ra.split("\n"):
        line = line.strip(" ")
        if "import" in line and line[:1]!="#":
            allowimp = False
            # 0.3.0.10添加新特性，如果import 的上一句是 # keep import
            # 则这个import将不需要进行白名单验证
            if lastline=="# keep import":
                allowimp=True
            else:
                for allowimport in __allow_import_keyword:
                    if allowimport in line:
                        # 如果这句import 中带有白名单的词语，则允许添加到import
                        allowimp = True
            if not allowimp:
                # # 如果不是引用的官方库，则将from xxx变成from plug.Home.ACCOUNT.Apps.plugname.xxx
                # if "from " in line:
                #     if "plug.Home." not in line:
                #         oldline=line
                #         line = line.replace("from ", "from plug.Home."+account+".Apps."+str_chkingplna+".")
                #         # 针对from .的操作，需要把..去掉
                #         line = line.replace("..","")
                #         print("IMPORT SELF FUNCTION:",line)
                #         LOADLIST[account][str_chkingplna]["import_path_head"].append(line)
                #         #将这句话给备注掉，不允许文本启用时运行这句import
                #         __replaceobj(str_py_file,oldline,line)
                # else:
                # 没有from的一律按照引用不允许的类来进行判断
                print( "IMPORT ERROR : IMPORT UNOPEN CLASS:", line)
            else:
                # 此处添加的是白名单的import
                LOADLIST[account][str_chkingplna]["import_path_head"].append(line)
        lastline=line


def __loading_py_functions(account):
    """
    开始将LOADPLUG里面的函数进行初始化执行
    """
    JWSCLS=weblocal.JWSCLS
    if account in LOADLIST:
        for plna in LOADLIST[account]:
            if "import_path_head" in LOADLIST[account][plna]:
                # 先对py插件脚本进行import，否则无法使用里面的函数
                for imp in LOADLIST[account][plna]["import_path_head"]:
                    print("IMPORTING : "+imp)
                    try:
                        exec(imp)
                    except Exception as e:
                        print("IMPORTING INNER-FUN ERROR["+plna+"]:"+imp)
                        traceback.print_exc()
                        print("=======[plug error end]=======")
                if "userhome" in LOADLIST[account][plna]:
                    # 该插件需要使用用户空间
                    exec(plna+"."+LOADLIST[account][plna]["userhome"]+".loadUser(\""+account+"\")")
                    exec(plna+"."+LOADLIST[account][plna]["userhome"]+".loadPlugName(\""+plna+"\")")
                    
            # 下面为加载所有找到的符合规范的插件接口函数，特征是plug_plugname_xxx的函数
            for itm in LOADLIST[account][plna]:
                if itm not in __specialfunction_names:
                    try:
                        JWSCLS.load_pluglist(LOADLIST[account][plna][itm]["plugname"],
                                            LOADLIST[account][plna][itm]["action"],
                                            eval(LOADLIST[account][plna][itm]["plugname"] +
                                                "." + LOADLIST[account][plna][itm]["functionname"]),
                                            LOADLIST[account][plna][itm]["filterlist"])
                    except:
                        print("[!!!]["+plna+"]Unknow Import:"+
                            LOADLIST[account][plna][itm]["plugname"] +
                            "." + LOADLIST[account][plna][itm]["functionname"]+"  ")


def __replaceobj(filepath,fromstr,tostr):
    """
    把指定行替换成另一个指定行
    """
    scr=open(filepath,"r",encoding="utf-8")
    ra=scr.read()
    scr.close()
    wtxt=open(filepath,"w",encoding="utf-8")
    ra=ra.replace(fromstr,tostr)
    wtxt.write(ra)
    wtxt.close()
    print("WRITE REPLACE CMD OVER")


def loading_plugzip(zip_pth,account_name):
    """
    zip_pth : zip文件当前的文件路径
    return : true/false

    将送入的指定zip文件作为新的插件导入到插件库中，
    如果插件已经存在，会被整个文件夹删除然后重新创建。
    必须满足下面条件：
        文件内包含：
            info.json   (用于储存web窗体信息和使用提示等)
            # 插件名.py   (后台插件主要功能)<选参>
            # index.html  (web窗体界面)<选参>

    可以存在testplug/testplug/*.*的情况
    """
    # 创建tmp文件夹，用于解压压缩包，并判断是否存在两层文件夹的情况，如果是，则提取与压缩包相同名称的文件夹
    print("####[START LOAD]####")
    tmpfold = fso.get_propath("tmp","")
    fso.foldexist(tmpfold)
    # 将zip复制到temp目录下
    print("# from zip:" + zip_pth)
    if not os.path.exists(zip_pth):
        print("# zip file NOE.")
        return False
    zipname = fso.get_file_extension(zip_pth)
    tmpzipfile=fso.appfold("tmp/"+zipname)
    print("# using zipfile:"+tmpzipfile)
    # 如果tmp目录下还有这个zip_name的文件，删除
    if os.path.exists(tmpzipfile):
        print("# Del tmp old file",True)
        os.remove(tmpzipfile)
    tmpplugfold = fso.appfold("tmp/"+fso.get_file_name(zip_pth))
    if os.path.exists(tmpplugfold):
        print("# DEL exist PLUGFOLDER in TMP")
        shutil.rmtree(tmpplugfold)
    os.mkdir(tmpplugfold)
    # 创建独立文件夹，用zip文件作为文件夹名称
    print("# copyto:"+tmpzipfile)
    shutil.copyfile(zip_pth, tmpzipfile)
    # 准备进行解压
    print("# UNZIPING...")
    fso.unzip(tmpzipfile, tmpplugfold)
    # 检查json.info
    # indexhtml = fso.get_propath("tmp",plugname+"/index.html")
    # plugpy = fso.get_propath("tmp",plugname+"/"+plugname+".py")
    print("# search info.json:")
    # if os.path.exists(infojson):
    #     # # 找到的主要的文件，可以开始进行转移
    #     # # DEBUG:没有进行文件内容检查，需要以后加上，否则py文件可能会有恶意代码对minipi进行破坏
    #     # 
    #     # # 重启minipi以启动插件
    #     # print("# Load Plug :"+res,True)
    #     # return res
    #     # # os._exit(3)
    #     return True
    for frompath,foldname,files in os.walk(tmpplugfold):
        for filna in files:
            if filna=="info.json":
                infojson=fso.format_path(frompath+"/"+filna)
                print("# FOUND info.json:"+infojson)
                res = __loading_plugfiles(frompath,account_name)
                return res
                # 重启minipi以启动插件
                # os._exit(3)
    print("# Load PLUG FALSE")
    return False


def __loading_plugfiles(foldpath:str,account_name:str)->bool:
    """
    对插件进行转移，并导入到配置文件中，0.3版本后不再使用绝对路径
    [local]
        enable_list= testplug

    [testplug]
        python_scr = plugs/Home/Apps/testplug/testplug.py
        html_index = plugs/Home/Apps/testplug/index.html
        json_scr = /home/jimuti/minipi/plugs/Home/Apps/testplug/info.json
        user_index = plugs/Home/Apps/testplug/user.html
        {"title":"测试一下" , "width":500 , "plugname":"testplug" }
    """
    # 把文件夹的文件转移到Apps下
    print("### into thr")
    # 优先检查json配置
    
    infojson=fso.format_path(foldpath+"/info.json")
    print("### checking info.json : "+infojson)
    f = open(infojson, "r", encoding="utf-8")
    jstxt = f.read()
    f.close()
    try:
        jsobj = json.loads(jstxt)
        if "plugname" not in jsobj:
            print("### no plugname found , exit")
            return False
    except:
        print("### info.js error up")
        return False
    plugname=jsobj["plugname"]
    print("### init folders")
    plugfold = get_plug_folder(plugname)
    usrpfold= getUserFolder(account_name, plugname)
    print("#### init plug folder ,ready to copy")
    # 不允许覆盖旧的插件，防止删除旧插件的配置文件
    fso.foldexist(plugfold)
    print("### coping files ...")
    # 根据info所在目录，将当前文件夹所有文件进行转移
    fso.copyfolder(foldpath,plugfold)
    print("### setting plug-ini")
    """
    0.3版本 info.json 文档参数
    # 旧接口文档
    {   "plugname": "aliyunddns",       #！必填
        "title": "无标题",              #选填
        "width": "500",                 #选填
        "need": "无",                   #选填
        "author": "积木体",             #选填
        "instuction": "未添加说明信息"  #选填
    }

    # 新增部分
    pathindex : "index.html" ,    指向主页，当访问127.0.0.1 / plugname 会访问当前插件目录下的主页文件
    pathfiles : "Files" ,    指向静态文件目录，路径为127.0.0.1/Files/  plugname /js/xxx
    pathhtmls : "HTML" ,    指向html模板文件夹,路径为127.0.0.1/plugname/  user/xxx
    pathpysrc : "plugname.py" ,    指向后端脚本文件
    pathuser  : "user.html" ,    指向插件操控页面的模板文件
    routeindex : "/",    网页路由设置，设置该路由后，可将指定的url改成当前插件指向的目标
    routefiles : "/",    静态文件路由设置，设置该路由后，可将当前的静态文件路由到指定路径
    pathautojs : "startup.js"   当住用户控制页面打开时自动加载指定脚本
    """
    # 开始配置info文件
    plugini=getUserFolder(account_name,plugname)
    fso.wini(plugini, plugname, "pathinfo",plugname+"/info.json")
    __setPathSetting(jsobj,account_name,plugname,"pathuser")
    __setPathSetting(jsobj,account_name,plugname,"pathindex")
    __setPathSetting(jsobj,account_name,plugname,"pathpysrc")
    __setPathSetting(jsobj,account_name,plugname,"pathfiles")
    __setPathSetting(jsobj,account_name,plugname,"pathhtmls")
    __setPathSetting(jsobj,account_name,plugname,"pathautojs")
    # 单独检查路由项
    if "routeindex" in jsobj:
        routeindex=jsobj["routeindex"]
        if routeindex!="":
            print("### ROUTE INDEX : "+routeindex)
            fso.wini(plugini, plugname, "routeindex",routeindex)
    
    if "routefiles" in jsobj:
        routefiles=jsobj["routefiles"]
        if routefiles!="":
            print("### ROUTE FILES : "+routefiles)
            fso.wini(plugini, plugname, "routefiles",routefiles)
    # 文件转移完毕,自动启用
    fso.item_appendini(plugini, "local", "enable_list", plugname)
    print("### wini and return true")
    return True

def __setPathSetting(jsobj:dict,account:str,plugname:str,keyword:str):
    """
    keyword : 需要检查与添加的键名称
    """
    if keyword in jsobj:
        plugini=get_fold(account)
        filename=jsobj[keyword]
        # 如果文件前面带有斜杠，则进行清除
        if filename[:1]=="/" or filename[:1]=="\\":
            filename=filename[1:]
        filpath=fso.format_path(get_fold(account) + "/Apps/"+plugname+"/"+filename)
        if not os.path.exists(filpath) or filename=="":
            print("### Ignore ["+keyword+"] : ",filpath)
            return
        fso.wini(plugini, plugname, keyword,plugname+"/"+filename)

def __copyfiles(srcfold,dstfold):
    """
    将指定文件夹复制到另一个文件夹，如果存在相同名称的文件，会先删除再复制
    """
    # for sfold,nowfold,files in os.walk(srcfold):
    #     for filna in files:
    #         fil=fso.format_path(sfold+"/"+filna)
    #         if 
    pass


"""
########################################################################
#  网页配置专用插件接口，用于网页上的各种设置保存与控制
########################################################################
"""
def plug_web_accountadd(jsl,rejsl):
    """
    # 添加账户
    # 添加完毕后账户默认管理员
    # [ newaccount ,fromaccount ,pwd,confirmpwd]
    """
    fromact=jsl["fromaccount"]
    newact=jsl["newaccount"]
    pwd=jsl["pwd"]
    cfrpwd=jsl["confirmpwd"]
    rjs=sck.jsonapi("127.0.0.1:"+local.WEB_API_PORT,{"series":"minipi","action":"accountadd",
        "fromaccount":fromact,"newaccount":newact,"pwd":pwd,"confirmpwd":cfrpwd})
    for itm in rjs:
        rejsl[itm]=rjs[itm]

def plug_web_accountshow(jsl,rejsl):
    """
    获取当前网页端的登陆账号
    """
    rjs=sck.jsonapi("127.0.0.1:"+local.WEB_API_PORT,{"series":"minipi","action":"accountshow"})
    rejsl["result"]="ok"
    if "list" in rjs:
        rejsl["list"]=rjs["list"]

def plug_web_accountdel(jsl,rejsl):
    """
    # 删除网页端指定账户，需要填入指定的账户与账户的UID
    # [ account,uid ]
    """
    act=jsl["account"]
    uid=jsl["uid"]
    sck.jsonapi("127.0.0.1:"+local.WEB_API_PORT,{"series":"minipi","action":"accountdel","account":act,"uid":uid})
    rejsl["result"]="ok"
    

def plug_web_accountchange(jsl,rejsl):
    """
    # 修改账号密码信息
    # [ account , okw , nkw ]
    """
    act=jsl["account"]
    okw=jsl["okw"]
    nkw=jsl["nkw"]
    rjs=sck.jsonapi("127.0.0.1:"+local.WEB_API_PORT,{"series":"minipi","action":"accountchg",
                                "account":act,"okw":okw,"nkw":nkw})
    for itm in rjs:
        rejsl[itm]=rjs[itm]


def plug_web_port(jsl,rejsl):
    """
    修改当前web服务器监听端口，默认80
    修改后需要软重启
    <port>
    """
    port=str(jsl["port"])
    from Armoury import formatfun as ffun
    if not ffun.is_number(port):
        rejsl["result"]="false"
        return
    fso.wini(local.INI_LOCALSETTING,"web","port",port)
    rejsl["result"]="ok"


def plug_web_settingset(jsl,rejsl):
    """
    # 设置指定配置的值
    name , value , account
    """
    account_name=jsl["account"]
    webini=get_webini(account_name)
    fso.wini(webini,"normal",jsl["name"],jsl["value"])
    rejsl["result"]="ok"

def plug_web_settingget(jsl,rejsl):
    """
    读取指定名字的配置的值
    name , defaultvalue , account
    """
    account_name=jsl["account"]
    webini=get_webini(account_name)
    ri=fso.rini(webini,"normal",jsl["name"],jsl["defaultvalue"])
    rejsl["result"]="ok"
    rejsl["value"]=ri

def plug_web_settinggets(jsl,rejsl):
    """
    读取指定名字的配置的值,一次性读取多个,用逗号隔开
    name
    /name="name1,name2,name3"
    return:{result:ok,value={name1:value1 , name2:value2 ..}}
    """
    account_name=jsl["account"]
    names=jsl["name"].split(",")
    vullst={}
    webini=get_webini(account_name)
    for itm in names:
        if itm!="":
            ri=fso.rini(webini,"normal",itm,"")
            vullst[itm]=ri
    rejsl["value"]=vullst
    rejsl["result"]="ok"

def plug_web_timeout(jsl,rejsl):
    """
    开启或关闭网页的自动退出功能
    当超时时间为0，则不再使用自动注销功能
    ###############################
    [ timeout=1-9999<0> ]
    """
    account_name=jsl["account"]
    webini=fso.format_path(get_fold(account_name) + "/web_setting.ini")
    timeouts=int(jsl["timeout"])
    if timeouts>0:
        # 启用超时，单位秒
        fso.wini(webini,"normal","timeout",str(timeouts))
        rejsl["autologout"]="true"
    else:
        fso.wini(webini,"normal","timeout","0")
        rejsl["autologout"]="false"
    rejsl["result"]="ok"

def plug_web_startup():
    """
    获取带有<plugname>_startup的函数
    """
    
def get_plug_folder(plugname:str,infopath:bool=False)->str:
    """
    获取当前账户的ini配置文件路径,
    \n infopath=true，则获取的是这个账户的info.json文件路径
    \nreturn : str
    """
    if infopath:
        return local.FOLDER_PLUG + "/" + plugname + "/info.json" 
    else:
        return local.FOLDER_PLUG + "/" + plugname

def getUserFolder(account:str,plugname:str="")->str:
    """
    获取用户目录，如果带插件名称，则返回该插件
    只获取路径，不判断是否存在
    return : str
    """
    if plugname=="":
        return local.FOLDER_USER + "/" + account
    return local.FOLDER_USER + "/" + account + "/" + plugname

def getUserPlugs(account:str,withfilter:bool=False)->list:
    """
    获取指定用户下的所有插件。
    目前插件的判断为：所有文件夹为插件
    withfilter ： 当filter为true，会排除用户空间下的禁用目录
    """
    ll=[]
    filterlist=[]
    if withfilter:
        fini=getUserFolder(account)+"/pluglist.ini"
        rall=fso.item_listini(fini,"disable","plugname")
        for itm in rall:
            filterlist.append(itm)
    for dirna in os.listdir(getUserFolder(account)):
        if os.path.isdir(local.FOLDER_USER + "/" + account + "/" + dirna) and dirna not in filterlist:
            ll.append(dirna)
    return ll


# def get_webini(account_name):
#     """
#     获取当前插件的web_ini配置文件路径,
#     .../plugs/Home/ACCOUNT/web_setting.ini
#     return : str
#     """
#     return fso.get_propath("plug","Home/"+account_name+"/web_setting.ini").replace("\\","/")

