# pigeon.py for minipi
"""
minipi系统自带的内部内网控制工具
规则：
    1：所有配置文件放在setting文件夹下；
    2：所有配置文件必须PigeonSetting_开头；
    3：add 与addhp区别在于一个使用固定IP，一个使用动态域名；
    4: 内部自有不可修改的连接需要使用'__应用名_ID号'
应用：
    已经定下的应用名称与使用规范：
    PGN : 使用 jmt.ink 
    WEB : 
    API :
    HPPGN : 
    HPWEB :
    !! HTTP未添加
    HTTP : jmt.ink:8880，默认type为http，需要使用 custom_domains = xxxx.jimuti.net <本连接只有type , local_port , cistom_domains >
"""
import Armoury.fso as fso
import os
from threading import Thread

class pigeon:
    cid = 0
    account = ""
    frppath = "\\Pigeon"
    frpinipath = "\\PigeonSetting.ini"
    servername=""
    ininame=""

    def __init__(self,servername):
        self.ininame="PigeonSetting_"+servername+".ini"
        self.servername=servername
        if fso.islinux():
            if fso.sysbit() == 64:
                self.frppath = fso.appfold("plug/Pigeon_x64")
            else:
                self.frppath = fso.appfold("plug/Pigeon_x86")
            self.frpinipath = fso.appfold("setting/"+self.ininame)
            os.popen("chmod 777 \"" + self.frppath + "\"")
            os.popen("chmod 777 \"" + self.frpinipath + "\"")
        else:
            if fso.sysbit() == 64:
                self.frppath = fso.appfold("plug/Pigeon_x64.exe")
            else:
                self.frppath = fso.appfold("plug/Pigeon_x86.exe")
            self.frpinipath = fso.appfold("setting/"+self.ininame)
        if "common" not in fso.rallini(self.frpinipath):
            fso.wini(self.frpinipath, "common", "server_addr", "0.0.0.0")
            fso.wini(self.frpinipath, "common", "server_port", "0")

    def checkFrp(self):
        """
        （仅Linux下）
        检查pigeon进程是否存在，并重新运行
        返回值：无
        """
        if fso.islinux():
            restr = os.popen("screen -ls").read()
            if restr.find("pigeon_"+self.servername) == -1:
                os.popen("screen -dmS pigeon_"+self.servername+" " + self.frppath +
                         " -c " + self.frpinipath)
                print("restart frpc:",self.servername)
        else:
            pass

    def addcli(self, name, protocoltype, localip, localport, remoteport):
        """
        添加一个pigeon连接的配置并写入到ini
        如果使用相同名称进行添加，会重写配置
        返回值：无
        """
        fso.wini(self.frpinipath, name, "type", protocoltype, "\n")
        fso.wini(self.frpinipath, name, "local_ip", localip, "\n")
        fso.wini(self.frpinipath, name, "local_port", localport, "\n")
        fso.wini(self.frpinipath, name, "remote_port", remoteport, "\n")

    def clr(self):
        """
        清空整个pigeon配置文件，等于删掉新建一个空的txt
        返回值：无
        """
        fso.wtxt(self.frpinipath, "", False)

    def delcli(self, name):
        """
        删除某个名字的连接的配置信息
        返回值：无
        """
        fso.delini(self.frpinipath, name)

    # def addlocal(self,remoteport):
    #     self.addcli("",)

    def infoall(self)->list:
        """
        打印所有配置文件的连接信息
        """
        ll=[]
        frpinifolder = fso.appfold("setting")
        for itm in os.listdir(frpinifolder):
            if "PigeonSetting_" in itm:
                fpth=frpinifolder+"/"+itm
                rall=fso.rallini(fpth)
                for pgnname in rall:
                    if pgnname!="common":
                        tmpjs={}
                        for kv in rall[pgnname]:
                            tmpjs[kv]=rall[pgnname][kv]
                        tmpjs["name"]=pgnname
                        print(tmpjs)
                        ll.append(tmpjs)
        return ll

    def info(self):
        """
        读取整个pigeon的配置文件
        返回值：js-ini
        """
        iniif = fso.rallini(self.frpinipath)
        return iniif

    def mod(self,name,new_name="",new_local_ip="",
            new_local_port="",new_type=""):
        """
        修改pigeon的信息，留空则不修改
        *******************************
        name : 需要修改的pgn的项名
        new_name/local_ip/local_port/type ：新的信息
        """
        allpgn=self.info()
        for pgnname,itm in allpgn.items():
            if pgnname==name:
                now_name=pgnname
                now_loip=itm["local_ip"]
                now_loport=itm["local_port"]
                now_type=itm["type"]
                now_rmport=itm["remote_port"]

                if new_name!="":
                    now_name=new_name
                if new_local_ip!="":
                    now_loip=new_local_ip
                if new_local_port!="":
                    now_loport=new_local_port
                if new_type!="":
                    now_type=new_type

                if new_name!=pgnname:
                    fso.delini(self.frpinipath,pgnname)
                fso.wini(self.frpinipath, now_name, "type", now_type, "\n")
                fso.wini(self.frpinipath, now_name, "local_ip", now_loip, "\n")
                fso.wini(self.frpinipath, now_name, "local_port", now_loport, "\n")
                fso.wini(self.frpinipath, now_name, "remote_port", now_rmport, "\n")

    def start(self, server_addr, server_port):
        """
        开始运行pigeon
        返回值：无
        """
        fso.wini(self.frpinipath, "common", "server_addr", server_addr, "\n")
        fso.wini(self.frpinipath, "common", "server_port", server_port, "\n")
        if fso.islinux():
            # linux系统下的操作
            restr = os.popen("screen -ls").read()
            if restr.find("pigeon_"+self.servername) == -1:
                os.popen("screen -dmS pigeon_"+self.servername+" " + self.frppath +
                         " -c " + self.frpinipath)
        else:
            # windows 下的操作
            taskfindlist=fso.taskfind(self.ininame)
            if len(taskfindlist)==0:
                thr = Thread(target=self._running_win,name="minipi_pigeon_"+self.servername)
                thr.start()
                

    def _running_win(self):
        # window 下执行命令无法停止，使用线程
        print("\"" + self.frppath + "\" -c \"" + self.frpinipath + "\"")
        os.popen("\"" + self.frppath + "\" -c \"" + self.frpinipath + "\"")

    def stop(self):
        """
        终止pigeon
        """
        if fso.islinux():
            os.popen("screen -X -S pigeon_"+self.servername+" quit")
        else:
            fso.taskfindandkill(self.ininame)
    
    def restart(self):
        """
        重启pigeon
        """
        self.stop()
        s_addr=fso.rini(self.frpinipath, "common", "server_addr", "0.0.0.0")
        s_port=fso.rini(self.frpinipath, "common", "server_port", "0")
        self.start(s_addr,s_port)

    class clientinfo:
        NAME=""
        PORT="0"
        IS_ONLINE=False
        PGN_ID="aaaaaa"
        CONN_COUNT=0

#####################################
# 创建默认转发，并开机自动连接，主要是调试连接与网页界面连接
#####################################
DEVID = ""
def init_pigeon_client(WEB_HTTPPORT:str,did:str):
    """
    初始化所有系统默认转发
    WEB_HTTPPORT : 当前网站所使用的转发端口
    devid : 当前设备序列号
    """
    # pgn_ssh_name = "SSH"
    # pgn_web_name = "WEB"
    # pgn_api_name = "API"
    # pgn_pgn_name = "PGN"
    pgn_hpweb_name = "HPWEB"
    pgn_hppgn_name = "HPPGN"
    HPPGN_SERVER_URL = "ls.jimuti.com"
    HPPGN_SERVER_PORT = "6911"
    HPWEB_PGN_PORT = "7080"
    HPPGN_PGN_PORT = "7022"
    exg=fso.execGroup()
    global DEVID
    DEVID=did
    exg.add(__init_pigeon,pgn_hpweb_name, HPPGN_SERVER_URL, HPWEB_PGN_PORT,
                  HPPGN_SERVER_PORT, WEB_HTTPPORT, True)
    exg.add(__init_pigeon,pgn_hppgn_name, HPPGN_SERVER_URL,
                  HPPGN_PGN_PORT, HPPGN_SERVER_PORT, "", False)
    exg.exec(None)

def __init_pigeon(pgn_appname: str, server_url: str, server_listenport: str, server_apiport: str, local_port: str, isdefault: bool):
    """
    \n pgn_appname : 应用名称，五大常驻转发应用
                    SSH
                    API
                    WEB
                    HPWEB
                    HPPGN
    \n isdefault : 该转发是否创建默认转发：
                true：  会创建__appname_myid的转发到指定端口，一般用于自带转发例如api，会自动运行
                false： 不会创建默认名称转发，当配置为空，不会自动运行
    """
    server_listenport = str(server_listenport)
    server_apiport = str(server_apiport)
    local_port = str(local_port)

    pgn_name = "__"+pgn_appname+"_"+DEVID
    pgncls = pigeon(pgn_appname)
    pgnlist = pgncls.info()
    if isdefault:
        if pgn_name not in pgnlist:
            # 申请地址与端口
            from Armoury import sock
            rejs = sock.jsonapi("http://"+server_url+":"+server_apiport,
                               {"series": "minipi", "action": "requestport", "serverport": server_listenport, "name": pgn_name})
            if rejs["result"] == "ok":
                fport = rejs["port"]
                print("GET REQUEST PORT ["+pgn_appname+"]" + fport)
                pgncls.addcli(pgn_name, "tcp", "127.0.0.1", local_port, fport)
        pgncls.start(server_url, server_listenport)
    else:
        if len(pgnlist) > 1:
            pgncls.start(server_url, server_listenport)
