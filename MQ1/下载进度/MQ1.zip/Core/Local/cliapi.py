from Core.Local import local
from Armoury import sock
from Armoury import fso


def api_request_download():
    """
    请求下载文件，询问是否在忙碌状态
    """
    tmpjs = {"action": "request_download",
            "id": local.MY_ID.lower()}
    return __get(tmpjs)

def api_download_finish()->dict:
    """
    下载完毕，告诉服务器已经完成，可以开放下一个下载
    发送该命令有可能会被服务器丢包，所以需要进行result确认
    """
    tmpjs = {"action": "download_finish",
            "id": local.MY_ID.lower()}
    rejs = {"result": "false", "errmsg": "timeout"}
    c = 10
    while c > 0:
        c = c-1
        rejs = __get(tmpjs)
        if rejs["result"] == "ok":
            break
    return rejs

def __get(datajs)->dict:
    """
    """
    return {}

# def _sockget(datajs):
#     """
#     发送加密url并返回js结果，必定含有result结果
#     return:<js>
#     """
#     tcpobj = sock.tcpClass()
#     apiurl = _initjs(datajs)
#     # print(apiurl)
#     rdat = tcpobj.get(apiurl)
#     if rdat != "":
#         dejs = sck.de_b64js(rdat)
#         return dejs
#     else:
#         return {"result": "false", "errmsg": "timeout"}

# def _initjs(datajs):
#     """
#     将指定参数初始化成完整的带加密链接的访问链接
#     """
#     tim=int(time.time())
#     enstr = sck.en_jsurl(datajs,tim)
#     return "http://"+self.target_addr+":"+str(self.target_port)+"/?" + enstr