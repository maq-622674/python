
from Armoury import fso


MAX_DOWNLOAD_COUNT = 3
DOWNLOADLIST={}

def cmd_request_download(jsl, rejsl):
    """
    客户端请求下载
    id
    """
    global DOWNLOADLIST
    if len(DOWNLOADLIST) >= MAX_DOWNLOAD_COUNT:
        rejsl["result"] = "false"
        rejsl["errmsg"] = "max_clients"
        print("[REQ DL]:"+"MAX CLIENTS")
    else:
        DOWNLOADLIST[jsl["id"]] = fso.now()
        rejsl["result"] = "ok"
        print("[REQ DL]:"+jsl["id"])
