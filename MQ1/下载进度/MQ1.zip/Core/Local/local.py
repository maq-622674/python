from Armoury import fso
from Armoury import sock
from Core.WWW import weblocal
from Core.Local import plugmgmt
from Core.Local import pigeon
import os
import shutil
import sys
import time
import io
###########################################################
#   修改区
###########################################################
# 版本号
VER = "0.0.17.5"
# 是否将数据打印到网页
ECHO_PRINT =False
# 是否将错误打印到网页
ECHO_ERR=False
###########################################################
MY_ID = "0000000"
# 使用的端口
PORT_WEB = "85"
# 打印重定向
OLD_stdout_print=sys.stdout
STDOUT=io.StringIO()
STDERR=io.StringIO()
# 内部目录的文件夹绝对路径
FOLDER_MAIN     = fso.appfold()
FOLDER_SETTING  = FOLDER_MAIN + "/setting"
FOLDER_USER     = FOLDER_MAIN + "/user"
FOLDER_PLUG     = FOLDER_MAIN + "/plug"
FOLDER_TMP      = FOLDER_MAIN + "/tmp"
###############################
#L
FOLDER_CORE     = FOLDER_MAIN + "/Core"
###############################
# 配置文件
INI_LOCALSETTING= FOLDER_SETTING + "/local.ini"
# 内置文件下载链接
URL_7Z = "http://a.jimuti.com/Files/Pack/7zx64.exe"
if fso.sysbit()==32:
    URL_7Z= "http://a.jimuti.com/Files/Pack/7zx86.exe"
URL_7ZDLL = "http://a.jimuti.com/Files/Pack/7zx64.dll"
if fso.sysbit()==32:
    URL_7Z= "http://a.jimuti.com/Files/Pack/7zx86.dll"
UPDATE_SERVER_URL="http://a.jimuti.com"
# 0.3版本后，默认增加一个高速通道，用于访问网页
HPPGN_SERVER_URL = "ls.jimuti.com"
HPPGN_SERVER_PORT = "6911"
HPWEB_PGN_PORT = "7080"
HPPGN_PGN_PORT = "7022"

def checkdownload(filename):
    """
    检查plug下的指定文件是否存在，如果不存在则去文件中心把文件下载下来
    """
    if not os.path.exists(fso.appfold("plug/"+filename)):
        sock.download("http://a.jimuti.com/Files/Pack/" +
                     filename, filename, FOLDER_PLUG)
def checkplugs():
    # if not os.path.exists(FOLDER_PLUG):
    #     print("# Create plugs")
    #     os.mkdir(FOLDER_PLUG)
    if fso.islinux():
        # 仅处理pigeon
        if fso.sysbit() == 64:
            checkdownload("Pigeon_x64")
        else:
            checkdownload("Pigeon_x86")
    else:
        if fso.sysbit() == 64:
            checkdownload("Pigeon_x64.exe")
            checkdownload("7zx64.dll")
            if not os.path.exists(fso.appfold("plug/7z.dll")):
                print("# Downloading 7z.exe")
                sock.download(
                    "http://a.jimuti.com/Files/Pack/7zx64.exe", "7z.exe", FOLDER_PLUG)
        else:
            checkdownload("Pigeon_x86.exe")
            checkdownload("7z.dll")
            if not os.path.exists(fso.appfold("plug/7z.exe")):
                print("# Downloading 7z.exe")
                sock.download(
                    "http://a.jimuti.com/Files/Pack/7zx86.exe", "7z.exe", FOLDER_PLUG)
            checkdownload("Pigeon_x86.exe")
    
    # 每次启动，更新plug/API内的文件
    # 如果localini的develop = True ，则说明该后端为开发环境，不进行操作
    # if fso.rini(SETTINGINI,"local","develop","")=="true":
    #     errbox.log("Develop : Not Move API",True)
    # else:
    #     if os.path.exists(FOLDER_PLUGAPI): shutil.rmtree(FOLDER_PLUGAPI)
    #     fso.foldexist(FOLDER_PLUGAPI)
    #     capi=fso.get_propath("api")
    #     for itm in os.listdir(capi):
    #         if not os.path.isdir(capi+"/"+itm): shutil.copy(capi+"/"+itm,FOLDER_PLUGAPI+"/"+itm)
    #     if os.name=="posix":
    #         os.popen("sync && sync")

def clear_tempfolder():
    """
    启动时运行，删除所有临时文件夹和临时文件，
    主要有：
    /tmp
    """
    if os.path.exists(FOLDER_TMP):
        shutil.rmtree(FOLDER_TMP)

def echo(*msg):
    sys.stdout=OLD_stdout_print
    print(*msg)
    sys.stdout=STDOUT

def get_sysarch() -> str:
    """
    获取当前电脑系统的代号缩写
    A3 A6 L3 L6 M3 M6 W3 W6 XX
    """
    from Armoury import installer
    arch = installer.getCpuArch()
    if os.name == "posix" and arch == "armhf":
        return "A3"
    elif os.name == "posix" and arch == "arm64":
        return "A6"
    elif os.name == "posix" and arch == "x86":
        return "L3"
    elif os.name == "posix" and arch == "x64":
        return "L6"
    elif os.name == "nt" and arch == "armhf":
        return "M3"
    elif os.name == "nt" and arch == "arm64":
        return "M6"
    elif os.name == "nt" and arch == "x86":
        return "W3"
    elif os.name == "nt" and arch == "x64":
        return "W6"
    else:
        return "XX"



def ver_num(vername)->int:
    """
    获取当前版本号的子节点数字
    main.sub.cmd.index
    return : int
    """
    global VER
    vername = vername.lower()
    if vername == "main":
        return int(VER.split(".")[0])
    elif vername == "sub":
        return int(VER.split(".")[1])
    elif vername == "cmd":
        return int(VER.split(".")[2])
    elif vername == "index":
        return int(VER.split(".")[3])
    else:
        print("[VER_ERR]:Read VER ERR.")
    return 0


def ver_set(vername, value):
    """
    设置当前版本号
    vername : <main.sub.cmd.index>
    value   : <strint>
    """
    global VER
    value = str(value).strip(" ")
    if value == "":
        return
    ss = VER.split(".")
    if vername == "main":
        VER = value + "." + ss[1] + "." + ss[2] + "." + ss[3]
    elif vername == "sub":
        VER = ss[0] + "." + value + "." + ss[2] + "." + ss[3]
    elif vername == "cmd":
        VER = ss[0] + "." + ss[1] + "." + value + "." + ss[3]
    elif vername == "index":
        VER = ss[0] + "." + ss[1] + "." + ss[2] + "." + value

def _startup():
    """
    """
    # 如果是Linux环境，导出run脚本
    if os.name=="posix":
        runsh=fso.appfold("run.sh")
        fso.wtxt(runsh,"nohup "+sys.executable+" "+fso.appfold("Base.py")+" &",False)
        runsh=fso.appfold("debug.sh")
        fso.wtxt(runsh,sys.executable+" "+fso.appfold("Base.py"),False)
        os.popen("chmod 777 "+runsh).read()
        rall=os.popen("ps |grep python").read()
        if rall.count("/Base.py")>1:
            print("mutil process running , quit.")
            os._exit(0)
    # 如果是windows系统，强制创建plug并下载7z文件
    # z7=FOLDER_PLUG+"/7z.exe"
    # z7dll=FOLDER_PLUG+"/7zx64.dll"
    # if fso.sysbit()==32:
    #     z7dll=FOLDER_PLUG+"/7zx86.dll"
    # if os.path.exists(z7) or not os.path.exists(z7dll):
    #     # 不存哎7z文件，进行下载
    #     from Armoury import sock
    #     sock.download(URL_7Z,"7z.exe",FOLDER_PLUG)
    #     sock.download(URL_7ZDLL,z7dll,FOLDER_PLUG)
    checkplugs()

def dir_copy(): 
    '''
    L
    功能说明:
    如果plug/API不存在
    把Core/API复制到plug/API
    '''
    if not os.path.exists(FOLDER_PLUG+'/API'):
        #fso.foldexist(FOLDER_PLUG+'/API')
        #shutil.copytree(olddir,newdir) #olddir和newdir都只能是目录，且newdir必须不存在
        shutil.copytree(FOLDER_CORE+'/API',FOLDER_PLUG+'/API') #olddir和newdir都只能是目录，且newdir必须不存在
        

def init_mq():
    """初始化麻雀"""
    global MY_ID,PORT_WEB
    # 初始化系统所需要的文件夹
    fso.foldexist(FOLDER_SETTING)
    fso.foldexist(FOLDER_PLUG)
    fso.foldexist(FOLDER_USER)
    clear_tempfolder()
    # 开始执行初始化
    _startup()
    ###########################
    #L
    dir_copy()
    ###########################
    # 开始检查设备是否存在ID号，如果不存在，则需要手动填写一个
    did=fso.rini(INI_LOCALSETTING,"local","id","")
    if did=="":
        # 说明这个设备没有初始化序列号，需要进行手动填写一次
        # 不存在ID，必须要求填写ID才能启动
        sys.stdout=OLD_stdout_print
        if ver_num("cmd") > 100000:
            # DEBUG：当前取消客户端id填写
            mid = "P" + time.strftime("%H%M%S", time.localtime())
            fso.wini(INI_LOCALSETTING, "local", "id", mid)
        else:
            mid = ""
            print("###########[ Input Device ID]#############")
            print("# if input one char , than the char will be index .")
            while mid == "":
                days = fso.caldays(
                    "2017-12-08", time.strftime("%Y-%m-%d", time.localtime()))
                days = hex(days).replace("0x", "").upper()
                # 0.3版本后增加新特性，设备ID号包含了CPU和系统信息
                mid = input("Input Device ID NOW(0" + get_sysarch() +
                            days + "n)(len<>7 repeat):")
                if len(mid) == 1:
                    # 仅仅输入了一个字符，则作为序号位
                    mid = ("1" + get_sysarch() + days + mid).upper()
                if len(mid) != 7:
                    mid = ""
            mid = mid.upper()
            fso.wini(INI_LOCALSETTING, "local", "id", mid)
        sys.stdout=STDOUT
    MY_ID = fso.rini(INI_LOCALSETTING, "local", "id", "0000000")
    print("ID:",MY_ID)
    print("VER:",VER)
    # 启动Pigeon
    pigeon.init_pigeon_client(PORT_WEB,MY_ID)
    # 初始化网页环境
    PORT_WEB = fso.rini(INI_LOCALSETTING,"web","port","80")
    weblocal.init_web()
    # 初始化插件
    plugmgmt.init()
    
