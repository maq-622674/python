'''
Center Control Code
中枢命令控制器
'''

# import socket
# from socket import *
from threading import Thread
import Armoury.fso as fso
import Armoury.sock as sock
import Armoury.formatfun as funs
# import Armoury.errbox as errbox
import time
import os
import json
# URL编码与解码
# from urllib.parse import unquote
from Core.Local import local
from Core.Local import cliapi
from Core.Tool import run
from Core.Dev import sysinfo
# from Core.Local import db_init, pigeon
# from Core.Local import local ,bcc ,bcc_svr
# from Core.Local import ccc_plugs
# from Core.Dev import sysinfo, dev





class udpEcho:
    """
    UDP监听线程，主要处理UDP广播回应，端口为7000
    """
    port = 0
    myname = "minipi"

    def start(self, port, myname):
        self.port = port
        self.myname = myname
        udps = Thread(target=self.thr_loop, name="minipi_udpecho")
        udps.start()

    def thr_loop(self):
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.bind(('0.0.0.0', int(self.port)))
        while True:
            data, addr = s.recvfrom(1024)
            if "minipi" in data.decode():
                rstr=json.dumps({self.myname:sock.getinterfaces()}).encode()
                s.sendto(rstr, addr)

def cmd_aaa(jsl,rejsl):
    """
    测试专用
    """
    fso.msg_add("调用aaa接口")
    jsl["result"]="ok"

def cmd_alias(jsl, rejsl):
    """
    # 设置设备别名
    <name>=>设置了name为写入，空参数为读取
    """
    if "name" not in jsl:
        rejsl["name"] = fso.rini(
            local.INI_LOCALSETTING, "local", "alias", local.MY_ID)
        rejsl["result"] = "ok"
        return
    fso.wini(local.INI_LOCALSETTING, "local", "alias", jsl["name"])
    local.ALIAS=jsl["name"]
    rejsl["result"] = "ok"

def cmd_cpu(jsl, rejsl):
    """
    执行命令
    cmd
    """
    rejsl["result"]="ok"
    rejsl["cpu"]=sysinfo.cpu()

def cmd_cmd(jsl, rejsl):
    """
    执行命令
    cmd
    """
    cmd = jsl["cmd"]
    echob = os.popen(cmd).read()
    rejsl["result"] = "ok"
    print(echob)
    print(type(echob))
    rejsl["echo"] = echob

def cmd_createplug(jsl,rejsl):
    """
    创建新的空插件应用
    \n< "account","name" >
    """
    act=jsl["account"]
    plugna=jsl["name"]
    from . import plugmgmt
    if plugmgmt.create(act,plugna):
        rejsl["result"]="ok"
        return
    rejsl["result"]="false"

def cmd_getid( jsl, rejsl):
    """
    获取当前设备ID <>
    """
    rejsl["id"] = local.MY_ID
    rejsl["result"] = "ok"


def cmd_info(jsl,rejsl):
    """
    """
    print("ID:",local.MY_ID)
    print("VER:",local.VER)
    print("TIME:",fso.now())
    rejsl["result"]="ok"

def cmd_route(jsl,rejsl):
    """
    打印当前网页路由表
    """
    # from Core.WWW import weblocal
    # JWSCLS=weblocal.JWSCLS
    # show=fso.showBox()
    # show.addHead("URL","Target")
    # for itm,vul in JWSCLS.ROUTE_LIST.items():
    #     show.addItem(itm,str(vul))
    # show.addMsg("Web URL Route list ")
    # for itm,vul in JWSCLS.ROUTE_FILE_LIST.items():
    #     show.addItem(itm,str(vul))
    # show.show()
    from Core.WWW import weblocal
    JWSCLS=weblocal.JWSCLS
    print("======= Web URL Route list =======")
    for itm,vul in JWSCLS.ROUTE_LIST.items():
        print("(URL)",itm," => ",str(vul.__name__))
    for itm,vul in JWSCLS.ROUTE_FILE_LIST.items():
        print("(FILE)",itm," => ",str(vul))
    print("=================================")
    rejsl["result"]="ok"

def cmd_rs(jsl,rejsl):
    """
    重启
    """
    rejsl["REQ_RESTART"]="true"
    rejsl["result"]="ok"
    

def cmd_thrlist(jsl,rejsl):
    """
    显示当前minipi所有线程
    """
    import threading
    ll=[]
    for itm in threading.enumerate():
        thrna=str(itm)
        if "<Thread(" in thrna:
            ll.append(thrna.replace("<Thread(","").split(",")[0])
    rejsl["result"]="ok"
    # rejsl["total"]=str(len(threading.enumerate()))
    rejsl["list"]=ll

msglist=[]
def cmd_time(jsl,rejsl):
    """
    获取设备当前时间 <>
    """
    global msglist
    # from plug.API import queuemsg
    rejsl["time"] = fso.now()
    # if len(queuemsg.HASMSG)>0:
    #     rejsl["msg"]=queuemsg.HASMSG

    if local.STDOUT.tell()>0:
        local.STDOUT.seek(0)
        ll=local.STDOUT.readlines()
        ll.reverse()
        for line in ll:
            msglist.append(line)
        local.STDOUT.truncate(0)
    if local.STDERR.tell()>0:
        local.STDERR.seek(0)
        ll=local.STDERR.readlines()
        ll.reverse()
        for line in ll:
            if " - - " not in line:
                msglist.append("Er:"+line)
        local.STDERR.truncate(0)
    if len(msglist)>0:
        rejsl["msg"]=[]
        rejsl["msg"].extend(msglist)
        msglist.clear()
    rejsl["result"] = "ok"

def Extract_File(szpath,filePath,target):
    """
    """
    #target=target+"/"
    zip_command = szpath+ " "+"x %s -y -o%s"%(filePath,target)
    code=os.system(zip_command)
    return code
def cmd_new(jsl,rejsl):
    """
    新的升级
    """
    dlurl="http://ls.jimuti.com:808/File/uploads/jimuti/MQ1.zip"
    folder_tmp=fso.appfold("tmp")
    fso.foldexist(folder_tmp)
    dlres=sock.download(dlurl,"MQ.zip",folder_tmp)
    if not dlres:
        rejsl["result"]="false"
        rejsl["errmsg"]="download err"
        return
    dlfil=folder_tmp + "/MQ.zip"
    if os.name=="posix":
        os.popen("unzip -o \""+dlfil+"\" -d \"" + fso.appfold() + "\"").read()
    elif os.name=="nt":
        z7=local.FOLDER_PLUG+"/7z.exe"
        os.popen(z7+" x -tzip -y \""+dlfil+"\" -o\""+fso.appfold()+"\"")
    rejsl["result"]="ok"
    rejsl["REQ_RESTART"]="true"
    
    #import os
    #print("A",os.getpid())
    # folder_tmp=fso.appfold("tmp")
    # fso.foldexist(folder_tmp)
    # print("cd folder_tmp:",folder_tmp)
    # a
    # a1=os.system('cd '+fso.appfold())
    # if a1=='0':
    #     a2=os.system('type nul>aaa.py')
    #     if a2=='0':
    #         a3=os.system('echo print(1+2)>aaa.py')
    #         if a3=='0':
    #             a4=os.system('python aaa.py')

    #    
    #         print("a3",a3)
    #         a3=os.system('echo print(1+2)>aaa.py')

    # durl="http://ls.jimuti.com:808/File/uploads/jimuti/MQ1.zip"
    # folder_tmp=fso.appfold("tmp")
   
    # fso.foldexist(folder_tmp)
    # dlres=sock.download(durl,"MQ1.zip",folder_tmp)
    # print("是否下载成功:",dlres)
    # if not dlres:
    #     rejsl["result"]="false"
    #     rejsl["errmsg"]="download err"
    #     return     
    # dlfil=folder_tmp+"/MQ1.zip"
    # if os.name=='nt':
    #     z7=local.FOLDER_PLUG+"/7z.exe"  
    #     #运行new.py 
    #     print("123112111111111111111111111")
        
    #     if dlres:
    #         time.sleep(2)
    #         a1=os.system('cd '+folder_tmp)
    #         print("a1",a1)
    #         if a1=='0':
    #             print("a2",a2)
    #             a2=os.system('type nul>aaa.py')
    #             if a2=='0':
    #                 print("a3",a3)
    #                 a3=os.system('echo print(1+2)>aaa.py')
        
    #     #os......  code=Extract_File(z7,dlfil,fso.appfold())
    #                 if a3=='0':
    #                     os._exit(1)
        
        #print("执行cmd命令完成,还不知道成功与否 (0就是成功):",code)
       
        # try:
        #     print("马上退出")
        #     os._exit()
        # except:
        #     pass
        # finally:
        #     code=Extract_File(z7,dlfil,fso.appfold())
        #     print("退出后要干的事")
        #     aa=os.system("cd "+fso.appfold())
        #     if aa==0:
        #         bb=os.system("aa.bat")
        #         print("bb:",bb)
                


    
def cmd_update(jsl,rejsl):
    """
    升级
    """
    dlurl="http://ls.jimuti.com:808/Files/Pack/MQ1.zip"
    folder_tmp=fso.appfold("tmp")
    fso.foldexist(folder_tmp)
    dlres=sock.download(dlurl,"MQ.zip",folder_tmp)
    if not dlres:
        rejsl["result"]="false"
        rejsl["errmsg"]="download err"
        return
    dlfil=folder_tmp + "/MQ.zip"
    if os.name=="posix":
        os.popen("unzip -o \""+dlfil+"\" -d \"" + fso.appfold() + "\"").read()
    elif os.name=="nt":
        z7=local.FOLDER_PLUG+"/7z.exe"
        os.popen(z7+" x -tzip -y \""+dlfil+"\" -o\""+fso.appfold()+"\"")
    rejsl["result"]="ok"
    rejsl["REQ_RESTART"]="true"
    # run.run_delay(5)
    

def cmd_ver( jsl, rejsl):
    """
    获取设备当前版本号 <>
    """
    rejsl["ver"] = local.VER
    rejsl["result"] = "ok"

def plug_test(jsl,rejsl):
    """
    """
    rejsl["result"]="ok"



###################################################################################
def _chkver():
    while True:
        update(False)
        time.sleep(60)


def update(showmsg=True):
    infourl = ("http://"+local.UPDATE_SERVER_URL+"/Files/minipi/" +
               str(local.ver_num("main")) + "." +
               str(local.ver_num("sub")) + "/" + 
               str(local.VER_NOWINDEX) + "/info.txt")
    tcpCls = sock.tcpClass()
    try:
        rstr = tcpCls.get(infourl)
    except Exception as e:
        print("Read Version ERR:"+repr(e))
        rstr=""
    if rstr == "":
        # errbox.log(str(local.ver_num("main")) + "." +
        #        str(local.ver_num("sub")) + "/" + 
        #        str(local.VER_NOWINDEX) +" check update error",True)
        return
    nextver = fso.listread(rstr, "nextver")
    fsize = fso.listread(rstr, "size")
    if funs.is_number(fsize):
        fsize = int(fsize)
    else:
        fsize = 0
    if fsize == 0:
        print("FILE UPD_SIZE ERROR:", fsize)
        return
    # allstr = fso.listreadall(rstr, "list")
    if len(nextver.split(".")) != 4:
        print("# Ver ERR")
        return
    now_subinx =local.ver_num("sub")
    now_verinx = local.VER_NOWINDEX

    next_mainver = int(nextver.split(".")[0])
    next_subver = int(nextver.split(".")[1])
    next_cmdver = int(nextver.split(".")[2])
    next_verinx = int(nextver.split(".")[3])

    # 主版本号未做设置

    # 次级版本号功能接口相似，但是架构产生了改变,会通过修改setting进行升级后重启
    if next_subver>now_subinx:
        pass

    if next_verinx > now_verinx:
        # 首先判断命令号是否相同，命令号不同会被直接忽略
        if next_cmdver != local.ver_num("cmd"):
            # 命令号相同才允许更新，否则忽略此版本
            fso.wini(local.INI_LOCALSETTING, "local", "verindex", next_verinx)
            local.VER_NOWINDEX = int(next_verinx)
            return
        # 0.1.16版本后，需要服务器进行下载序列排队
        rejs = cliapi.api_request_download()
        if rejs["result"] == "ok":
            print("# [REQ_DL]: ALLOW.")
        else:
            print("# [REQ_DL]: BUSY.")
            return

        updname = "update-" + nextver + ".upd"
        # 版本号增加，启用更新
        fileurl = ("http://"+local.UPDATE_SERVER_URL+"/Files/minipi/" +
                   str(next_mainver) +
                   "." +
                   str(next_subver) +
                   "/" +
                   str(next_verinx) +
                   "/" + updname)
        print("UPDATE DOWNLOADING.")
        print("download:",fileurl)
        # 下载的名字一定要固定为update.udp，否则warden不识别
        sock.download(fileurl, "update.upd", fso.appfold())
        print("Download Finish.")
        rejs = cliapi.api_download_finish()
        print("ReASK From SVR:",rejs)
        # 一旦编号有上升，就写到配置文件里面去
        fso.wini(local.INI_LOCALSETTING, "local", "verindex", next_verinx)
        local.VER_NOWINDEX = int(next_verinx)
        # 解压前，先把插件退出，否则可能会出现无法覆盖的情况
        # 后续：插件文件夹不再是主体文件夹，按需进行配置更新
        # try:
        #     pgn.stop()
        # except:
        #     print("PGN Not running")
        os._exit(9)
    else:
        if showmsg:
            print("NEWEST VER.")