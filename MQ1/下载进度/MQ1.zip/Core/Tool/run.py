import time
from Armoury import fso
import os
import sys

def run_delay(delay_s:str):
    """
    """
    delay_s = str(delay_s)
    fold=fso.appHome()
    if os.name=="posix":
        sh=fold+"/run.sh"
        fso.wtxt(sh,"ping 127.0.0.1 -c "+delay_s +"\n"+
             "\"" + sys.executable +"\" \""+ fso.appfold("Base.py")+"\"",False)
        os.popen("chmod 777 "+sh).read()
    elif os.name=="nt":
        sh=fold+"/run.bat"
        fso.wtxt(sh,"TIMEOUT /T "+delay_s+" /NOBREAK " +"\n"+
             "cmd /c \"\"" + sys.executable +"\" \""+ fso.appfold("Base.py")+"\"\"",False)
    os.popen("cmd /c \"" + sh +"\"")
    os._exit(0)

