"""
文件型管理库工具
"""

class classFDBClint(object):
    """
    子库类
    """
    def __init__(self):
        """
        """
        pass

class classFDB:
    """
    将指定文件夹设置为文件库
    """
    def __init__(self):
        self.ACCOUNT = ""

    def load(self,folder_path:str):
        """
        加载指定文件夹
        """ 
        pass
