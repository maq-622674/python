import os
from Armoury import fso
from threading import Thread

def start_up_time():
    """
    获取系统开机时间
    """
    pass

def cpu()->str:
    """
    """
    global CPU60S_LIST
    if len(CPU60S_LIST)>0:
        return CPU60S_LIST[-1]
    return "0"

def __cpu_use()->str:
    """
    """
    if os.name=="posix":
        rall=os.popen("mpstat 1 1").read()
        cpu_free=rall.strip().split(" ")[-1]
        cpu=str(round(100.0-float(cpu_free)),2)
    elif os.name=="nt":
        rall=os.popen("cmd /c "+fso.appHome("cpu.bat")).read()
        cpu=rall.split(" ")[-1].replace("\n","")
    return cpu

CPU60S_LIST = []
def cpu60s():
    """
    60秒内cpu的运行情况
    """
    thr=Thread(target=_thr_cpu60s,name="SYSINFO_CPU60S")
    thr.start()


def _thr_cpu60s():
    """
    线程：重复计算cpu使用率
    """
    global CPU60S_LIST
    while True:
        CPU60S_LIST.append(__cpu_use())
        if len(CPU60S_LIST)>60:
            CPU60S_LIST.pop(0)
  
cpu60s()