#####################################################
# 不同平台的功能函数
#####################################################
import os

def check_device():
    """
    查询当前运行设备的环境

    - W32
    - W64
    - L32
    - L64
    针对以下设备返回特殊值
    - HD3   :   DV300芯片
    - HC5   :   CV500
    - HE3   :   EV300
    - OPZ   :   orange pi 3
    """
    pass



def get_sysarch() -> str:
    """获取系统版本缩写符号

    A3 A6 L3 L6 M3 M6 W3 W6 XX
    """
    from Armoury import installer
    arch = installer.getCpuArch()
    if os.name == "posix" and arch == "armhf":
        return "A3"
    elif os.name == "posix" and arch == "arm64":
        return "A6"
    elif os.name == "posix" and arch == "x86":
        return "L3"
    elif os.name == "posix" and arch == "x64":
        return "L6"
    elif os.name == "nt" and arch == "armhf":
        return "M3"
    elif os.name == "nt" and arch == "arm64":
        return "M6"
    elif os.name == "nt" and arch == "x86":
        return "W3"
    elif os.name == "nt" and arch == "x64":
        return "W6"
    else:
        return "XX"